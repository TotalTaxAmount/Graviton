package net.minecraft.advancements.critereon;

import com.google.common.collect.ImmutableList;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.phys.Vec3;

public class DamageSourcePredicate {
   public static final DamageSourcePredicate f_25420_ = DamageSourcePredicate.Builder.m_25471_().m_25476_();
   private final List<TagPredicate<DamageType>> f_268608_;
   private final EntityPredicate f_25429_;
   private final EntityPredicate f_25430_;

   public DamageSourcePredicate(List<TagPredicate<DamageType>> p_270233_, EntityPredicate p_270167_, EntityPredicate p_270429_) {
      this.f_268608_ = p_270233_;
      this.f_25429_ = p_270167_;
      this.f_25430_ = p_270429_;
   }

   public boolean m_25448_(ServerPlayer p_25449_, DamageSource p_25450_) {
      return this.m_25444_(p_25449_.m_9236_(), p_25449_.m_20182_(), p_25450_);
   }

   public boolean m_25444_(ServerLevel p_25445_, Vec3 p_25446_, DamageSource p_25447_) {
      if (this == f_25420_) {
         return true;
      } else {
         for(TagPredicate<DamageType> tagpredicate : this.f_268608_) {
            if (!tagpredicate.m_269475_(p_25447_.m_269150_())) {
               return false;
            }
         }

         if (!this.f_25429_.m_36607_(p_25445_, p_25446_, p_25447_.m_7640_())) {
            return false;
         } else {
            return this.f_25430_.m_36607_(p_25445_, p_25446_, p_25447_.m_7639_());
         }
      }
   }

   public static DamageSourcePredicate m_25451_(@Nullable JsonElement p_25452_) {
      if (p_25452_ != null && !p_25452_.isJsonNull()) {
         JsonObject jsonobject = GsonHelper.m_13918_(p_25452_, "damage type");
         JsonArray jsonarray = GsonHelper.m_13832_(jsonobject, "tags", (JsonArray)null);
         List<TagPredicate<DamageType>> list;
         if (jsonarray != null) {
            list = new ArrayList<>(jsonarray.size());

            for(JsonElement jsonelement : jsonarray) {
               list.add(TagPredicate.m_269409_(jsonelement, Registries.f_268580_));
            }
         } else {
            list = List.of();
         }

         EntityPredicate entitypredicate = EntityPredicate.m_36614_(jsonobject.get("direct_entity"));
         EntityPredicate entitypredicate1 = EntityPredicate.m_36614_(jsonobject.get("source_entity"));
         return new DamageSourcePredicate(list, entitypredicate, entitypredicate1);
      } else {
         return f_25420_;
      }
   }

   public JsonElement m_25443_() {
      if (this == f_25420_) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         if (!this.f_268608_.isEmpty()) {
            JsonArray jsonarray = new JsonArray(this.f_268608_.size());

            for(int i = 0; i < this.f_268608_.size(); ++i) {
               jsonarray.add(this.f_268608_.get(i).m_269579_());
            }

            jsonobject.add("tags", jsonarray);
         }

         jsonobject.add("direct_entity", this.f_25429_.m_36606_());
         jsonobject.add("source_entity", this.f_25430_.m_36606_());
         return jsonobject;
      }
   }

   public static class Builder {
      private final ImmutableList.Builder<TagPredicate<DamageType>> f_268703_ = ImmutableList.builder();
      private EntityPredicate f_25468_ = EntityPredicate.f_36550_;
      private EntityPredicate f_25469_ = EntityPredicate.f_36550_;

      public static DamageSourcePredicate.Builder m_25471_() {
         return new DamageSourcePredicate.Builder();
      }

      public DamageSourcePredicate.Builder m_269507_(TagPredicate<DamageType> p_270455_) {
         this.f_268703_.add(p_270455_);
         return this;
      }

      public DamageSourcePredicate.Builder m_148229_(EntityPredicate p_148230_) {
         this.f_25468_ = p_148230_;
         return this;
      }

      public DamageSourcePredicate.Builder m_25472_(EntityPredicate.Builder p_25473_) {
         this.f_25468_ = p_25473_.m_36662_();
         return this;
      }

      public DamageSourcePredicate.Builder m_148233_(EntityPredicate p_148234_) {
         this.f_25469_ = p_148234_;
         return this;
      }

      public DamageSourcePredicate.Builder m_148231_(EntityPredicate.Builder p_148232_) {
         this.f_25469_ = p_148232_.m_36662_();
         return this;
      }

      public DamageSourcePredicate m_25476_() {
         return new DamageSourcePredicate(this.f_268703_.build(), this.f_25468_, this.f_25469_);
      }
   }
}