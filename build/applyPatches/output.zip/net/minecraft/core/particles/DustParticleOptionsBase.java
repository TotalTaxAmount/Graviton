package net.minecraft.core.particles;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Locale;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.util.Mth;
import org.joml.Vector3f;

public abstract class DustParticleOptionsBase implements ParticleOptions {
   public static final float f_175798_ = 0.01F;
   public static final float f_175799_ = 4.0F;
   protected final Vector3f f_175800_;
   protected final float f_175801_;

   public DustParticleOptionsBase(Vector3f p_253672_, float p_253735_) {
      this.f_175800_ = p_253672_;
      this.f_175801_ = Mth.m_14036_(p_253735_, 0.01F, 4.0F);
   }

   public static Vector3f m_252853_(StringReader p_254560_) throws CommandSyntaxException {
      p_254560_.expect(' ');
      float f = p_254560_.readFloat();
      p_254560_.expect(' ');
      float f1 = p_254560_.readFloat();
      p_254560_.expect(' ');
      float f2 = p_254560_.readFloat();
      return new Vector3f(f, f1, f2);
   }

   public static Vector3f m_253064_(FriendlyByteBuf p_254279_) {
      return new Vector3f(p_254279_.readFloat(), p_254279_.readFloat(), p_254279_.readFloat());
   }

   public void m_7711_(FriendlyByteBuf p_175809_) {
      p_175809_.writeFloat(this.f_175800_.x());
      p_175809_.writeFloat(this.f_175800_.y());
      p_175809_.writeFloat(this.f_175800_.z());
      p_175809_.writeFloat(this.f_175801_);
   }

   public String m_5942_() {
      return String.format(Locale.ROOT, "%s %.2f %.2f %.2f %.2f", BuiltInRegistries.f_257034_.m_7981_(this.m_6012_()), this.f_175800_.x(), this.f_175800_.y(), this.f_175800_.z(), this.f_175801_);
   }

   public Vector3f m_252837_() {
      return this.f_175800_;
   }

   public float m_175813_() {
      return this.f_175801_;
   }
}