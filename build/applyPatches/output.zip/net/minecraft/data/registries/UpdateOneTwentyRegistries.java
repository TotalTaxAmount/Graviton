package net.minecraft.data.registries;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.RegistrySetBuilder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.biome.BiomeData;
import net.minecraft.world.item.armortrim.TrimMaterials;
import net.minecraft.world.item.armortrim.TrimPatterns;
import net.minecraft.world.level.biome.MultiNoiseBiomeSourceParameterLists;

public class UpdateOneTwentyRegistries {
   private static final RegistrySetBuilder f_266008_ = (new RegistrySetBuilder()).m_254916_(Registries.f_266076_, TrimMaterials::m_266397_).m_254916_(Registries.f_266063_, TrimPatterns::m_266484_).m_254916_(Registries.f_256952_, BiomeData::m_272209_).m_254916_(Registries.f_273919_, MultiNoiseBiomeSourceParameterLists::m_274471_);

   public static CompletableFuture<HolderLookup.Provider> m_272206_(CompletableFuture<HolderLookup.Provider> p_273075_) {
      return p_273075_.thenApply((p_272828_) -> {
         RegistryAccess.Frozen registryaccess$frozen = RegistryAccess.m_206165_(BuiltInRegistries.f_257047_);
         HolderLookup.Provider holderlookup$provider = f_266008_.m_254929_(registryaccess$frozen, p_272828_);
         VanillaRegistries.m_271867_(p_272828_.m_255025_(Registries.f_256988_), holderlookup$provider.m_255025_(Registries.f_256952_));
         return holderlookup$provider;
      });
   }
}