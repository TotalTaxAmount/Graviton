package net.minecraft.data.worldgen.biome;

import net.minecraft.core.HolderGetter;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstapContext;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.levelgen.carver.ConfiguredWorldCarver;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

public abstract class BiomeData {
   public static void m_272174_(BootstapContext<Biome> p_273095_) {
      HolderGetter<PlacedFeature> holdergetter = p_273095_.m_255420_(Registries.f_256988_);
      HolderGetter<ConfiguredWorldCarver<?>> holdergetter1 = p_273095_.m_255420_(Registries.f_257003_);
      p_273095_.m_255272_(Biomes.f_48173_, OverworldBiomes.m_255251_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48202_, OverworldBiomes.m_194881_(holdergetter, holdergetter1, false, false, false));
      p_273095_.m_255272_(Biomes.f_48176_, OverworldBiomes.m_194881_(holdergetter, holdergetter1, true, false, false));
      p_273095_.m_255272_(Biomes.f_186761_, OverworldBiomes.m_194881_(holdergetter, holdergetter1, false, true, false));
      p_273095_.m_255272_(Biomes.f_48182_, OverworldBiomes.m_194881_(holdergetter, holdergetter1, false, true, true));
      p_273095_.m_255272_(Biomes.f_48203_, OverworldBiomes.m_194902_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48207_, OverworldBiomes.m_194910_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_220595_, OverworldBiomes.m_236670_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48205_, OverworldBiomes.m_194891_(holdergetter, holdergetter1, false, false, false));
      p_273095_.m_255272_(Biomes.f_48179_, OverworldBiomes.m_194891_(holdergetter, holdergetter1, false, false, true));
      p_273095_.m_255272_(Biomes.f_48149_, OverworldBiomes.m_194891_(holdergetter, holdergetter1, true, false, false));
      p_273095_.m_255272_(Biomes.f_48151_, OverworldBiomes.m_194885_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_186762_, OverworldBiomes.m_194891_(holdergetter, holdergetter1, true, true, false));
      p_273095_.m_255272_(Biomes.f_186763_, OverworldBiomes.m_194876_(holdergetter, holdergetter1, false));
      p_273095_.m_255272_(Biomes.f_186764_, OverworldBiomes.m_194876_(holdergetter, holdergetter1, true));
      p_273095_.m_255272_(Biomes.f_48206_, OverworldBiomes.m_194911_(holdergetter, holdergetter1, false));
      p_273095_.m_255272_(Biomes.f_48152_, OverworldBiomes.m_194911_(holdergetter, holdergetter1, true));
      p_273095_.m_255272_(Biomes.f_48157_, OverworldBiomes.m_194878_(holdergetter, holdergetter1, false, false));
      p_273095_.m_255272_(Biomes.f_48158_, OverworldBiomes.m_194878_(holdergetter, holdergetter1, false, true));
      p_273095_.m_255272_(Biomes.f_186765_, OverworldBiomes.m_194886_(holdergetter, holdergetter1, false));
      p_273095_.m_255272_(Biomes.f_186766_, OverworldBiomes.m_194886_(holdergetter, holdergetter1, false));
      p_273095_.m_255272_(Biomes.f_186767_, OverworldBiomes.m_194886_(holdergetter, holdergetter1, true));
      p_273095_.m_255272_(Biomes.f_186768_, OverworldBiomes.m_194878_(holdergetter, holdergetter1, true, false));
      p_273095_.m_255272_(Biomes.f_48222_, OverworldBiomes.m_255074_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_186769_, OverworldBiomes.m_254954_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48197_, OverworldBiomes.m_255279_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48159_, OverworldBiomes.m_194896_(holdergetter, holdergetter1, false));
      p_273095_.m_255272_(Biomes.f_48194_, OverworldBiomes.m_194896_(holdergetter, holdergetter1, false));
      p_273095_.m_255272_(Biomes.f_186753_, OverworldBiomes.m_194896_(holdergetter, holdergetter1, true));
      p_273095_.m_255272_(Biomes.f_186754_, OverworldBiomes.m_272060_(holdergetter, holdergetter1, false));
      p_273095_.m_255272_(Biomes.f_186755_, OverworldBiomes.m_194921_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_186756_, OverworldBiomes.m_194920_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_186757_, OverworldBiomes.m_194918_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_186758_, OverworldBiomes.m_194917_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_186759_, OverworldBiomes.m_255416_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48208_, OverworldBiomes.m_194914_(holdergetter, holdergetter1, false));
      p_273095_.m_255272_(Biomes.f_48212_, OverworldBiomes.m_194914_(holdergetter, holdergetter1, true));
      p_273095_.m_255272_(Biomes.f_48217_, OverworldBiomes.m_194888_(holdergetter, holdergetter1, false, false));
      p_273095_.m_255272_(Biomes.f_48148_, OverworldBiomes.m_194888_(holdergetter, holdergetter1, true, false));
      p_273095_.m_255272_(Biomes.f_186760_, OverworldBiomes.m_194888_(holdergetter, holdergetter1, false, true));
      p_273095_.m_255272_(Biomes.f_48166_, OverworldBiomes.m_254955_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48167_, OverworldBiomes.m_194905_(holdergetter, holdergetter1, false));
      p_273095_.m_255272_(Biomes.f_48170_, OverworldBiomes.m_194905_(holdergetter, holdergetter1, true));
      p_273095_.m_255272_(Biomes.f_48174_, OverworldBiomes.m_255326_(holdergetter, holdergetter1, false));
      p_273095_.m_255272_(Biomes.f_48225_, OverworldBiomes.m_255326_(holdergetter, holdergetter1, true));
      p_273095_.m_255272_(Biomes.f_48168_, OverworldBiomes.m_194899_(holdergetter, holdergetter1, false));
      p_273095_.m_255272_(Biomes.f_48171_, OverworldBiomes.m_194899_(holdergetter, holdergetter1, true));
      p_273095_.m_255272_(Biomes.f_48211_, OverworldBiomes.m_194908_(holdergetter, holdergetter1, false));
      p_273095_.m_255272_(Biomes.f_48172_, OverworldBiomes.m_194908_(holdergetter, holdergetter1, true));
      p_273095_.m_255272_(Biomes.f_48215_, OverworldBiomes.m_255280_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_151784_, OverworldBiomes.m_194895_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_151785_, OverworldBiomes.m_194922_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_220594_, OverworldBiomes.m_236671_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48209_, NetherBiomes.m_194831_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48201_, NetherBiomes.m_194835_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48200_, NetherBiomes.m_194834_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48199_, NetherBiomes.m_194832_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48175_, NetherBiomes.m_194833_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48210_, EndBiomes.m_255372_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48164_, EndBiomes.m_255137_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48163_, EndBiomes.m_255243_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48162_, EndBiomes.m_255123_(holdergetter, holdergetter1));
      p_273095_.m_255272_(Biomes.f_48165_, EndBiomes.m_255113_(holdergetter, holdergetter1));
   }

   public static void m_272209_(BootstapContext<Biome> p_273661_) {
      HolderGetter<PlacedFeature> holdergetter = p_273661_.m_255420_(Registries.f_256988_);
      HolderGetter<ConfiguredWorldCarver<?>> holdergetter1 = p_273661_.m_255420_(Registries.f_257003_);
      p_273661_.m_255272_(Biomes.f_271432_, OverworldBiomes.m_272060_(holdergetter, holdergetter1, true));
   }
}