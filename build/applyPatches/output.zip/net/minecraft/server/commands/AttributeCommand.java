package net.minecraft.server.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.Dynamic2CommandExceptionType;
import com.mojang.brigadier.exceptions.Dynamic3CommandExceptionType;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import java.util.UUID;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.ResourceArgument;
import net.minecraft.commands.arguments.UuidArgument;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;

public class AttributeCommand {
   private static final DynamicCommandExceptionType f_136434_ = new DynamicCommandExceptionType((p_212443_) -> {
      return Component.m_237110_("commands.attribute.failed.entity", p_212443_);
   });
   private static final Dynamic2CommandExceptionType f_136435_ = new Dynamic2CommandExceptionType((p_212445_, p_212446_) -> {
      return Component.m_237110_("commands.attribute.failed.no_attribute", p_212445_, p_212446_);
   });
   private static final Dynamic3CommandExceptionType f_136436_ = new Dynamic3CommandExceptionType((p_212448_, p_212449_, p_212450_) -> {
      return Component.m_237110_("commands.attribute.failed.no_modifier", p_212449_, p_212448_, p_212450_);
   });
   private static final Dynamic3CommandExceptionType f_136437_ = new Dynamic3CommandExceptionType((p_136497_, p_136498_, p_136499_) -> {
      return Component.m_237110_("commands.attribute.failed.modifier_already_present", p_136499_, p_136498_, p_136497_);
   });

   public static void m_245835_(CommandDispatcher<CommandSourceStack> p_251026_, CommandBuildContext p_250936_) {
      p_251026_.register(Commands.m_82127_("attribute").requires((p_212441_) -> {
         return p_212441_.m_6761_(2);
      }).then(Commands.m_82129_("target", EntityArgument.m_91449_()).then(Commands.m_82129_("attribute", ResourceArgument.m_247102_(p_250936_, Registries.f_256728_)).then(Commands.m_82127_("get").executes((p_248109_) -> {
         return m_247645_(p_248109_.getSource(), EntityArgument.m_91452_(p_248109_, "target"), ResourceArgument.m_245688_(p_248109_, "attribute"), 1.0D);
      }).then(Commands.m_82129_("scale", DoubleArgumentType.doubleArg()).executes((p_248104_) -> {
         return m_247645_(p_248104_.getSource(), EntityArgument.m_91452_(p_248104_, "target"), ResourceArgument.m_245688_(p_248104_, "attribute"), DoubleArgumentType.getDouble(p_248104_, "scale"));
      }))).then(Commands.m_82127_("base").then(Commands.m_82127_("set").then(Commands.m_82129_("value", DoubleArgumentType.doubleArg()).executes((p_248102_) -> {
         return m_245136_(p_248102_.getSource(), EntityArgument.m_91452_(p_248102_, "target"), ResourceArgument.m_245688_(p_248102_, "attribute"), DoubleArgumentType.getDouble(p_248102_, "value"));
      }))).then(Commands.m_82127_("get").executes((p_248112_) -> {
         return m_246137_(p_248112_.getSource(), EntityArgument.m_91452_(p_248112_, "target"), ResourceArgument.m_245688_(p_248112_, "attribute"), 1.0D);
      }).then(Commands.m_82129_("scale", DoubleArgumentType.doubleArg()).executes((p_248106_) -> {
         return m_246137_(p_248106_.getSource(), EntityArgument.m_91452_(p_248106_, "target"), ResourceArgument.m_245688_(p_248106_, "attribute"), DoubleArgumentType.getDouble(p_248106_, "scale"));
      })))).then(Commands.m_82127_("modifier").then(Commands.m_82127_("add").then(Commands.m_82129_("uuid", UuidArgument.m_113850_()).then(Commands.m_82129_("name", StringArgumentType.string()).then(Commands.m_82129_("value", DoubleArgumentType.doubleArg()).then(Commands.m_82127_("add").executes((p_248105_) -> {
         return m_136469_(p_248105_.getSource(), EntityArgument.m_91452_(p_248105_, "target"), ResourceArgument.m_245688_(p_248105_, "attribute"), UuidArgument.m_113853_(p_248105_, "uuid"), StringArgumentType.getString(p_248105_, "name"), DoubleArgumentType.getDouble(p_248105_, "value"), AttributeModifier.Operation.ADDITION);
      })).then(Commands.m_82127_("multiply").executes((p_248107_) -> {
         return m_136469_(p_248107_.getSource(), EntityArgument.m_91452_(p_248107_, "target"), ResourceArgument.m_245688_(p_248107_, "attribute"), UuidArgument.m_113853_(p_248107_, "uuid"), StringArgumentType.getString(p_248107_, "name"), DoubleArgumentType.getDouble(p_248107_, "value"), AttributeModifier.Operation.MULTIPLY_TOTAL);
      })).then(Commands.m_82127_("multiply_base").executes((p_248108_) -> {
         return m_136469_(p_248108_.getSource(), EntityArgument.m_91452_(p_248108_, "target"), ResourceArgument.m_245688_(p_248108_, "attribute"), UuidArgument.m_113853_(p_248108_, "uuid"), StringArgumentType.getString(p_248108_, "name"), DoubleArgumentType.getDouble(p_248108_, "value"), AttributeModifier.Operation.MULTIPLY_BASE);
      })))))).then(Commands.m_82127_("remove").then(Commands.m_82129_("uuid", UuidArgument.m_113850_()).executes((p_248103_) -> {
         return m_136458_(p_248103_.getSource(), EntityArgument.m_91452_(p_248103_, "target"), ResourceArgument.m_245688_(p_248103_, "attribute"), UuidArgument.m_113853_(p_248103_, "uuid"));
      }))).then(Commands.m_82127_("value").then(Commands.m_82127_("get").then(Commands.m_82129_("uuid", UuidArgument.m_113850_()).executes((p_248110_) -> {
         return m_136463_(p_248110_.getSource(), EntityArgument.m_91452_(p_248110_, "target"), ResourceArgument.m_245688_(p_248110_, "attribute"), UuidArgument.m_113853_(p_248110_, "uuid"), 1.0D);
      }).then(Commands.m_82129_("scale", DoubleArgumentType.doubleArg()).executes((p_248111_) -> {
         return m_136463_(p_248111_.getSource(), EntityArgument.m_91452_(p_248111_, "target"), ResourceArgument.m_245688_(p_248111_, "attribute"), UuidArgument.m_113853_(p_248111_, "uuid"), DoubleArgumentType.getDouble(p_248111_, "scale"));
      })))))))));
   }

   private static AttributeInstance m_246653_(Entity p_252177_, Holder<Attribute> p_249942_) throws CommandSyntaxException {
      AttributeInstance attributeinstance = m_136439_(p_252177_).m_21204_().m_246600_(p_249942_);
      if (attributeinstance == null) {
         throw f_136435_.create(p_252177_.m_7755_(), m_247618_(p_249942_));
      } else {
         return attributeinstance;
      }
   }

   private static LivingEntity m_136439_(Entity p_136440_) throws CommandSyntaxException {
      if (!(p_136440_ instanceof LivingEntity)) {
         throw f_136434_.create(p_136440_.m_7755_());
      } else {
         return (LivingEntity)p_136440_;
      }
   }

   private static LivingEntity m_245112_(Entity p_252105_, Holder<Attribute> p_248921_) throws CommandSyntaxException {
      LivingEntity livingentity = m_136439_(p_252105_);
      if (!livingentity.m_21204_().m_247503_(p_248921_)) {
         throw f_136435_.create(p_252105_.m_7755_(), m_247618_(p_248921_));
      } else {
         return livingentity;
      }
   }

   private static int m_247645_(CommandSourceStack p_251776_, Entity p_249647_, Holder<Attribute> p_250986_, double p_251395_) throws CommandSyntaxException {
      LivingEntity livingentity = m_245112_(p_249647_, p_250986_);
      double d0 = livingentity.m_246858_(p_250986_);
      p_251776_.m_81354_(Component.m_237110_("commands.attribute.value.get.success", m_247618_(p_250986_), p_249647_.m_7755_(), d0), false);
      return (int)(d0 * p_251395_);
   }

   private static int m_246137_(CommandSourceStack p_248780_, Entity p_251083_, Holder<Attribute> p_250388_, double p_250194_) throws CommandSyntaxException {
      LivingEntity livingentity = m_245112_(p_251083_, p_250388_);
      double d0 = livingentity.m_245892_(p_250388_);
      p_248780_.m_81354_(Component.m_237110_("commands.attribute.base_value.get.success", m_247618_(p_250388_), p_251083_.m_7755_(), d0), false);
      return (int)(d0 * p_250194_);
   }

   private static int m_136463_(CommandSourceStack p_136464_, Entity p_136465_, Holder<Attribute> p_250680_, UUID p_136467_, double p_136468_) throws CommandSyntaxException {
      LivingEntity livingentity = m_245112_(p_136465_, p_250680_);
      AttributeMap attributemap = livingentity.m_21204_();
      if (!attributemap.m_245160_(p_250680_, p_136467_)) {
         throw f_136436_.create(p_136465_.m_7755_(), m_247618_(p_250680_), p_136467_);
      } else {
         double d0 = attributemap.m_246117_(p_250680_, p_136467_);
         p_136464_.m_81354_(Component.m_237110_("commands.attribute.modifier.value.get.success", p_136467_, m_247618_(p_250680_), p_136465_.m_7755_(), d0), false);
         return (int)(d0 * p_136468_);
      }
   }

   private static int m_245136_(CommandSourceStack p_248556_, Entity p_248620_, Holder<Attribute> p_249456_, double p_252212_) throws CommandSyntaxException {
      m_246653_(p_248620_, p_249456_).m_22100_(p_252212_);
      p_248556_.m_81354_(Component.m_237110_("commands.attribute.base_value.set.success", m_247618_(p_249456_), p_248620_.m_7755_(), p_252212_), false);
      return 1;
   }

   private static int m_136469_(CommandSourceStack p_136470_, Entity p_136471_, Holder<Attribute> p_251636_, UUID p_136473_, String p_136474_, double p_136475_, AttributeModifier.Operation p_136476_) throws CommandSyntaxException {
      AttributeInstance attributeinstance = m_246653_(p_136471_, p_251636_);
      AttributeModifier attributemodifier = new AttributeModifier(p_136473_, p_136474_, p_136475_, p_136476_);
      if (attributeinstance.m_22109_(attributemodifier)) {
         throw f_136437_.create(p_136471_.m_7755_(), m_247618_(p_251636_), p_136473_);
      } else {
         attributeinstance.m_22125_(attributemodifier);
         p_136470_.m_81354_(Component.m_237110_("commands.attribute.modifier.add.success", p_136473_, m_247618_(p_251636_), p_136471_.m_7755_()), false);
         return 1;
      }
   }

   private static int m_136458_(CommandSourceStack p_136459_, Entity p_136460_, Holder<Attribute> p_250830_, UUID p_136462_) throws CommandSyntaxException {
      AttributeInstance attributeinstance = m_246653_(p_136460_, p_250830_);
      if (attributeinstance.m_22127_(p_136462_)) {
         p_136459_.m_81354_(Component.m_237110_("commands.attribute.modifier.remove.success", p_136462_, m_247618_(p_250830_), p_136460_.m_7755_()), false);
         return 1;
      } else {
         throw f_136436_.create(p_136460_.m_7755_(), m_247618_(p_250830_), p_136462_);
      }
   }

   private static Component m_247618_(Holder<Attribute> p_250602_) {
      return Component.m_237115_(p_250602_.m_203334_().m_22087_());
   }
}