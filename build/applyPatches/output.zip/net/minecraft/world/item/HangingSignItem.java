package net.minecraft.world.item;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.WallHangingSignBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class HangingSignItem extends StandingAndWallBlockItem {
   public HangingSignItem(Block p_251582_, Block p_250734_, Item.Properties p_250266_) {
      super(p_251582_, p_250734_, p_250266_, Direction.UP);
   }

   protected boolean m_246210_(LevelReader p_252032_, BlockState p_252230_, BlockPos p_252075_) {
      Block block = p_252230_.m_60734_();
      if (block instanceof WallHangingSignBlock wallhangingsignblock) {
         if (!wallhangingsignblock.m_247551_(p_252230_, p_252032_, p_252075_)) {
            return false;
         }
      }

      return super.m_246210_(p_252032_, p_252230_, p_252075_);
   }

   protected boolean m_7274_(BlockPos p_251351_, Level p_251684_, @Nullable Player p_248736_, ItemStack p_250117_, BlockState p_251334_) {
      boolean flag = super.m_7274_(p_251351_, p_251684_, p_248736_, p_250117_, p_251334_);
      if (!p_251684_.f_46443_ && !flag && p_248736_ != null) {
         BlockEntity blockentity = p_251684_.m_7702_(p_251351_);
         if (blockentity instanceof SignBlockEntity) {
            SignBlockEntity signblockentity = (SignBlockEntity)blockentity;
            p_248736_.m_7739_(signblockentity);
         }
      }

      return flag;
   }
}