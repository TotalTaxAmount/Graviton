package net.minecraft.world.item.crafting;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import net.minecraft.core.NonNullList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;

public class RecipeManager extends SimpleJsonResourceReloadListener {
   private static final Gson f_44005_ = (new GsonBuilder()).setPrettyPrinting().disableHtmlEscaping().create();
   private static final Logger f_44006_ = LogUtils.getLogger();
   private Map<RecipeType<?>, Map<ResourceLocation, Recipe<?>>> f_44007_ = ImmutableMap.of();
   private Map<ResourceLocation, Recipe<?>> f_199900_ = ImmutableMap.of();
   private boolean f_44008_;

   public RecipeManager() {
      super(f_44005_, "recipes");
   }

   protected void m_5787_(Map<ResourceLocation, JsonElement> p_44037_, ResourceManager p_44038_, ProfilerFiller p_44039_) {
      this.f_44008_ = false;
      Map<RecipeType<?>, ImmutableMap.Builder<ResourceLocation, Recipe<?>>> map = Maps.newHashMap();
      ImmutableMap.Builder<ResourceLocation, Recipe<?>> builder = ImmutableMap.builder();

      for(Map.Entry<ResourceLocation, JsonElement> entry : p_44037_.entrySet()) {
         ResourceLocation resourcelocation = entry.getKey();

         try {
            Recipe<?> recipe = m_44045_(resourcelocation, GsonHelper.m_13918_(entry.getValue(), "top element"));
            map.computeIfAbsent(recipe.m_6671_(), (p_44075_) -> {
               return ImmutableMap.builder();
            }).put(resourcelocation, recipe);
            builder.put(resourcelocation, recipe);
         } catch (IllegalArgumentException | JsonParseException jsonparseexception) {
            f_44006_.error("Parsing error loading recipe {}", resourcelocation, jsonparseexception);
         }
      }

      this.f_44007_ = map.entrySet().stream().collect(ImmutableMap.toImmutableMap(Map.Entry::getKey, (p_44033_) -> {
         return p_44033_.getValue().build();
      }));
      this.f_199900_ = builder.build();
      f_44006_.info("Loaded {} recipes", (int)map.size());
   }

   public boolean m_151269_() {
      return this.f_44008_;
   }

   public <C extends Container, T extends Recipe<C>> Optional<T> m_44015_(RecipeType<T> p_44016_, C p_44017_, Level p_44018_) {
      return this.m_44054_(p_44016_).values().stream().filter((p_220266_) -> {
         return p_220266_.m_5818_(p_44017_, p_44018_);
      }).findFirst();
   }

   public <C extends Container, T extends Recipe<C>> Optional<Pair<ResourceLocation, T>> m_220248_(RecipeType<T> p_220249_, C p_220250_, Level p_220251_, @Nullable ResourceLocation p_220252_) {
      Map<ResourceLocation, T> map = this.m_44054_(p_220249_);
      if (p_220252_ != null) {
         T t = map.get(p_220252_);
         if (t != null && t.m_5818_(p_220250_, p_220251_)) {
            return Optional.of(Pair.of(p_220252_, t));
         }
      }

      return map.entrySet().stream().filter((p_220245_) -> {
         return p_220245_.getValue().m_5818_(p_220250_, p_220251_);
      }).findFirst().map((p_220256_) -> {
         return Pair.of(p_220256_.getKey(), p_220256_.getValue());
      });
   }

   public <C extends Container, T extends Recipe<C>> List<T> m_44013_(RecipeType<T> p_44014_) {
      return List.copyOf(this.m_44054_(p_44014_).values());
   }

   public <C extends Container, T extends Recipe<C>> List<T> m_44056_(RecipeType<T> p_44057_, C p_44058_, Level p_44059_) {
      return this.m_44054_(p_44057_).values().stream().filter((p_220241_) -> {
         return p_220241_.m_5818_(p_44058_, p_44059_);
      }).sorted(Comparator.comparing((p_270043_) -> {
         return p_270043_.m_8043_(p_44059_.m_9598_()).m_41778_();
      })).collect(Collectors.toList());
   }

   private <C extends Container, T extends Recipe<C>> Map<ResourceLocation, T> m_44054_(RecipeType<T> p_44055_) {
      return (Map<ResourceLocation, T>)this.f_44007_.getOrDefault(p_44055_, Collections.emptyMap());
   }

   public <C extends Container, T extends Recipe<C>> NonNullList<ItemStack> m_44069_(RecipeType<T> p_44070_, C p_44071_, Level p_44072_) {
      Optional<T> optional = this.m_44015_(p_44070_, p_44071_, p_44072_);
      if (optional.isPresent()) {
         return optional.get().m_7457_(p_44071_);
      } else {
         NonNullList<ItemStack> nonnulllist = NonNullList.m_122780_(p_44071_.m_6643_(), ItemStack.f_41583_);

         for(int i = 0; i < nonnulllist.size(); ++i) {
            nonnulllist.set(i, p_44071_.m_8020_(i));
         }

         return nonnulllist;
      }
   }

   public Optional<? extends Recipe<?>> m_44043_(ResourceLocation p_44044_) {
      return Optional.ofNullable(this.f_199900_.get(p_44044_));
   }

   public Collection<Recipe<?>> m_44051_() {
      return this.f_44007_.values().stream().flatMap((p_220270_) -> {
         return p_220270_.values().stream();
      }).collect(Collectors.toSet());
   }

   public Stream<ResourceLocation> m_44073_() {
      return this.f_44007_.values().stream().flatMap((p_220258_) -> {
         return p_220258_.keySet().stream();
      });
   }

   public static Recipe<?> m_44045_(ResourceLocation p_44046_, JsonObject p_44047_) {
      String s = GsonHelper.m_13906_(p_44047_, "type");
      return BuiltInRegistries.f_256769_.m_6612_(new ResourceLocation(s)).orElseThrow(() -> {
         return new JsonSyntaxException("Invalid or unsupported recipe type '" + s + "'");
      }).m_6729_(p_44046_, p_44047_);
   }

   public void m_44024_(Iterable<Recipe<?>> p_44025_) {
      this.f_44008_ = false;
      Map<RecipeType<?>, Map<ResourceLocation, Recipe<?>>> map = Maps.newHashMap();
      ImmutableMap.Builder<ResourceLocation, Recipe<?>> builder = ImmutableMap.builder();
      p_44025_.forEach((p_220262_) -> {
         Map<ResourceLocation, Recipe<?>> map1 = map.computeIfAbsent(p_220262_.m_6671_(), (p_220272_) -> {
            return Maps.newHashMap();
         });
         ResourceLocation resourcelocation = p_220262_.m_6423_();
         Recipe<?> recipe = map1.put(resourcelocation, p_220262_);
         builder.put(resourcelocation, p_220262_);
         if (recipe != null) {
            throw new IllegalStateException("Duplicate recipe ignored with ID " + resourcelocation);
         }
      });
      this.f_44007_ = ImmutableMap.copyOf(map);
      this.f_199900_ = builder.build();
   }

   public static <C extends Container, T extends Recipe<C>> RecipeManager.CachedCheck<C, T> m_220267_(final RecipeType<T> p_220268_) {
      return new RecipeManager.CachedCheck<C, T>() {
         @Nullable
         private ResourceLocation f_220274_;

         public Optional<T> m_213657_(C p_220278_, Level p_220279_) {
            RecipeManager recipemanager = p_220279_.m_7465_();
            Optional<Pair<ResourceLocation, T>> optional = recipemanager.m_220248_(p_220268_, p_220278_, p_220279_, this.f_220274_);
            if (optional.isPresent()) {
               Pair<ResourceLocation, T> pair = optional.get();
               this.f_220274_ = pair.getFirst();
               return Optional.of(pair.getSecond());
            } else {
               return Optional.empty();
            }
         }
      };
   }

   public interface CachedCheck<C extends Container, T extends Recipe<C>> {
      Optional<T> m_213657_(C p_220280_, Level p_220281_);
   }
}
