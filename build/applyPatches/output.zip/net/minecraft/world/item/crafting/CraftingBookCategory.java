package net.minecraft.world.item.crafting;

import net.minecraft.util.StringRepresentable;

public enum CraftingBookCategory implements StringRepresentable {
   BUILDING("building"),
   REDSTONE("redstone"),
   EQUIPMENT("equipment"),
   MISC("misc");

   public static final StringRepresentable.EnumCodec<CraftingBookCategory> f_244644_ = StringRepresentable.m_216439_(CraftingBookCategory::values);
   private final String f_244018_;

   private CraftingBookCategory(String p_249346_) {
      this.f_244018_ = p_249346_;
   }

   public String m_7912_() {
      return this.f_244018_;
   }
}