package net.minecraft.world;

import java.util.function.IntFunction;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ByIdMap;
import net.minecraft.util.StringRepresentable;

public enum Difficulty implements StringRepresentable {
   PEACEFUL(0, "peaceful"),
   EASY(1, "easy"),
   NORMAL(2, "normal"),
   HARD(3, "hard");

   public static final StringRepresentable.EnumCodec<Difficulty> f_262746_ = StringRepresentable.m_216439_(Difficulty::values);
   private static final IntFunction<Difficulty> f_19018_ = ByIdMap.m_262839_(Difficulty::m_19028_, values(), ByIdMap.OutOfBoundsStrategy.WRAP);
   private final int f_19019_;
   private final String f_19020_;

   private Difficulty(int p_19026_, String p_19027_) {
      this.f_19019_ = p_19026_;
      this.f_19020_ = p_19027_;
   }

   public int m_19028_() {
      return this.f_19019_;
   }

   public Component m_19033_() {
      return Component.m_237115_("options.difficulty." + this.f_19020_);
   }

   public Component m_267622_() {
      return Component.m_237115_("options.difficulty." + this.f_19020_ + ".info");
   }

   public static Difficulty m_19029_(int p_19030_) {
      return f_19018_.apply(p_19030_);
   }

   @Nullable
   public static Difficulty m_19031_(String p_19032_) {
      return f_262746_.m_216455_(p_19032_);
   }

   public String m_19036_() {
      return this.f_19020_;
   }

   public String m_7912_() {
      return this.f_19020_;
   }
}