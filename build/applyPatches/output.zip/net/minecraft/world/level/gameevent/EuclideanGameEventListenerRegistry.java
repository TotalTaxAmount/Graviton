package net.minecraft.world.level.gameevent;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import net.minecraft.network.protocol.game.DebugPackets;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

public class EuclideanGameEventListenerRegistry implements GameEventListenerRegistry {
   private final List<GameEventListener> f_244422_ = Lists.newArrayList();
   private final Set<GameEventListener> f_244308_ = Sets.newHashSet();
   private final List<GameEventListener> f_244008_ = Lists.newArrayList();
   private boolean f_244249_;
   private final ServerLevel f_244607_;

   public EuclideanGameEventListenerRegistry(ServerLevel p_251510_) {
      this.f_244607_ = p_251510_;
   }

   public boolean m_245428_() {
      return this.f_244422_.isEmpty();
   }

   public void m_245531_(GameEventListener p_248767_) {
      if (this.f_244249_) {
         this.f_244008_.add(p_248767_);
      } else {
         this.f_244422_.add(p_248767_);
      }

      DebugPackets.m_179507_(this.f_244607_, p_248767_);
   }

   public void m_246052_(GameEventListener p_250006_) {
      if (this.f_244249_) {
         this.f_244308_.add(p_250006_);
      } else {
         this.f_244422_.remove(p_250006_);
      }

   }

   public boolean m_245521_(GameEvent p_251377_, Vec3 p_251445_, GameEvent.Context p_252317_, GameEventListenerRegistry.ListenerVisitor p_251422_) {
      this.f_244249_ = true;
      boolean flag = false;

      try {
         Iterator<GameEventListener> iterator = this.f_244422_.iterator();

         while(iterator.hasNext()) {
            GameEventListener gameeventlistener = iterator.next();
            if (this.f_244308_.remove(gameeventlistener)) {
               iterator.remove();
            } else {
               Optional<Vec3> optional = m_247048_(this.f_244607_, p_251445_, gameeventlistener);
               if (optional.isPresent()) {
                  p_251422_.m_247726_(gameeventlistener, optional.get());
                  flag = true;
               }
            }
         }
      } finally {
         this.f_244249_ = false;
      }

      if (!this.f_244008_.isEmpty()) {
         this.f_244422_.addAll(this.f_244008_);
         this.f_244008_.clear();
      }

      if (!this.f_244308_.isEmpty()) {
         this.f_244422_.removeAll(this.f_244308_);
         this.f_244308_.clear();
      }

      return flag;
   }

   private static Optional<Vec3> m_247048_(ServerLevel p_249585_, Vec3 p_251333_, GameEventListener p_251051_) {
      Optional<Vec3> optional = p_251051_.m_142460_().m_142502_(p_249585_);
      if (optional.isEmpty()) {
         return Optional.empty();
      } else {
         double d0 = optional.get().m_82557_(p_251333_);
         int i = p_251051_.m_142078_() * p_251051_.m_142078_();
         return d0 > (double)i ? Optional.empty() : optional;
      }
   }
}