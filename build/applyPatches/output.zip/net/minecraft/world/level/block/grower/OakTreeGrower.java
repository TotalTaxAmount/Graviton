package net.minecraft.world.level.block.grower;

import net.minecraft.data.worldgen.features.TreeFeatures;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;

public class OakTreeGrower extends AbstractTreeGrower {
   protected ResourceKey<ConfiguredFeature<?, ?>> m_213888_(RandomSource p_256119_, boolean p_256536_) {
      if (p_256119_.m_188503_(10) == 0) {
         return p_256536_ ? TreeFeatures.f_195111_ : TreeFeatures.f_195130_;
      } else {
         return p_256536_ ? TreeFeatures.f_195142_ : TreeFeatures.f_195123_;
      }
   }
}