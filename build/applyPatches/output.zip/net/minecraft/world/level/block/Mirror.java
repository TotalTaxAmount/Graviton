package net.minecraft.world.level.block;

import com.mojang.math.OctahedralGroup;
import com.mojang.serialization.Codec;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.util.StringRepresentable;

public enum Mirror implements StringRepresentable {
   NONE("none", OctahedralGroup.IDENTITY),
   LEFT_RIGHT("left_right", OctahedralGroup.INVERT_Z),
   FRONT_BACK("front_back", OctahedralGroup.INVERT_X);

   public static final Codec<Mirror> f_221524_ = StringRepresentable.m_216439_(Mirror::values);
   private final String f_221525_;
   private final Component f_153781_;
   private final OctahedralGroup f_54835_;

   private Mirror(String p_221529_, OctahedralGroup p_221530_) {
      this.f_221525_ = p_221529_;
      this.f_153781_ = Component.m_237115_("mirror." + p_221529_);
      this.f_54835_ = p_221530_;
   }

   public int m_54843_(int p_54844_, int p_54845_) {
      int i = p_54845_ / 2;
      int j = p_54844_ > i ? p_54844_ - p_54845_ : p_54844_;
      switch (this) {
         case FRONT_BACK:
            return (p_54845_ - j) % p_54845_;
         case LEFT_RIGHT:
            return (i - j + p_54845_) % p_54845_;
         default:
            return p_54844_;
      }
   }

   public Rotation m_54846_(Direction p_54847_) {
      Direction.Axis direction$axis = p_54847_.m_122434_();
      return (this != LEFT_RIGHT || direction$axis != Direction.Axis.Z) && (this != FRONT_BACK || direction$axis != Direction.Axis.X) ? Rotation.NONE : Rotation.CLOCKWISE_180;
   }

   public Direction m_54848_(Direction p_54849_) {
      if (this == FRONT_BACK && p_54849_.m_122434_() == Direction.Axis.X) {
         return p_54849_.m_122424_();
      } else {
         return this == LEFT_RIGHT && p_54849_.m_122434_() == Direction.Axis.Z ? p_54849_.m_122424_() : p_54849_;
      }
   }

   public OctahedralGroup m_54842_() {
      return this.f_54835_;
   }

   public Component m_153787_() {
      return this.f_153781_;
   }

   public String m_7912_() {
      return this.f_221525_;
   }
}