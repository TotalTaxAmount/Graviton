package net.minecraft.world.level.levelgen.blockpredicates;

import com.mojang.serialization.Codec;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;

public interface BlockPredicateType<P extends BlockPredicate> {
   BlockPredicateType<MatchingBlocksPredicate> f_190436_ = m_190449_("matching_blocks", MatchingBlocksPredicate.f_190479_);
   BlockPredicateType<MatchingBlockTagPredicate> f_198313_ = m_190449_("matching_block_tag", MatchingBlockTagPredicate.f_198336_);
   BlockPredicateType<MatchingFluidsPredicate> f_190437_ = m_190449_("matching_fluids", MatchingFluidsPredicate.f_190492_);
   BlockPredicateType<HasSturdyFacePredicate> f_198314_ = m_190449_("has_sturdy_face", HasSturdyFacePredicate.f_198315_);
   BlockPredicateType<SolidPredicate> f_190438_ = m_190449_("solid", SolidPredicate.f_190530_);
   BlockPredicateType<ReplaceablePredicate> f_190439_ = m_190449_("replaceable", ReplaceablePredicate.f_190521_);
   BlockPredicateType<WouldSurvivePredicate> f_190440_ = m_190449_("would_survive", WouldSurvivePredicate.f_190565_);
   BlockPredicateType<InsideWorldBoundsPredicate> f_190441_ = m_190449_("inside_world_bounds", InsideWorldBoundsPredicate.f_190463_);
   BlockPredicateType<AnyOfPredicate> f_190442_ = m_190449_("any_of", AnyOfPredicate.f_190381_);
   BlockPredicateType<AllOfPredicate> f_190443_ = m_190449_("all_of", AllOfPredicate.f_190370_);
   BlockPredicateType<NotPredicate> f_190444_ = m_190449_("not", NotPredicate.f_190505_);
   BlockPredicateType<TrueBlockPredicate> f_190445_ = m_190449_("true", TrueBlockPredicate.f_190554_);

   Codec<P> m_190452_();

   private static <P extends BlockPredicate> BlockPredicateType<P> m_190449_(String p_190450_, Codec<P> p_190451_) {
      return Registry.m_122961_(BuiltInRegistries.f_256906_, p_190450_, () -> {
         return p_190451_;
      });
   }
}