package net.minecraft.world.level.levelgen.feature;

import com.mojang.serialization.Codec;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.configurations.VegetationPatchConfiguration;

public class VegetationPatchFeature extends Feature<VegetationPatchConfiguration> {
   public VegetationPatchFeature(Codec<VegetationPatchConfiguration> p_160588_) {
      super(p_160588_);
   }

   public boolean m_142674_(FeaturePlaceContext<VegetationPatchConfiguration> p_160612_) {
      WorldGenLevel worldgenlevel = p_160612_.m_159774_();
      VegetationPatchConfiguration vegetationpatchconfiguration = p_160612_.m_159778_();
      RandomSource randomsource = p_160612_.m_225041_();
      BlockPos blockpos = p_160612_.m_159777_();
      Predicate<BlockState> predicate = (p_204782_) -> {
         return p_204782_.m_204336_(vegetationpatchconfiguration.f_161281_);
      };
      int i = vegetationpatchconfiguration.f_161289_.m_214085_(randomsource) + 1;
      int j = vegetationpatchconfiguration.f_161289_.m_214085_(randomsource) + 1;
      Set<BlockPos> set = this.m_213631_(worldgenlevel, vegetationpatchconfiguration, randomsource, blockpos, predicate, i, j);
      this.m_225330_(p_160612_, worldgenlevel, vegetationpatchconfiguration, randomsource, set, i, j);
      return !set.isEmpty();
   }

   protected Set<BlockPos> m_213631_(WorldGenLevel p_225311_, VegetationPatchConfiguration p_225312_, RandomSource p_225313_, BlockPos p_225314_, Predicate<BlockState> p_225315_, int p_225316_, int p_225317_) {
      BlockPos.MutableBlockPos blockpos$mutableblockpos = p_225314_.m_122032_();
      BlockPos.MutableBlockPos blockpos$mutableblockpos1 = blockpos$mutableblockpos.m_122032_();
      Direction direction = p_225312_.f_161284_.m_162107_();
      Direction direction1 = direction.m_122424_();
      Set<BlockPos> set = new HashSet<>();

      for(int i = -p_225316_; i <= p_225316_; ++i) {
         boolean flag = i == -p_225316_ || i == p_225316_;

         for(int j = -p_225317_; j <= p_225317_; ++j) {
            boolean flag1 = j == -p_225317_ || j == p_225317_;
            boolean flag2 = flag || flag1;
            boolean flag3 = flag && flag1;
            boolean flag4 = flag2 && !flag3;
            if (!flag3 && (!flag4 || p_225312_.f_161290_ != 0.0F && !(p_225313_.m_188501_() > p_225312_.f_161290_))) {
               blockpos$mutableblockpos.m_122154_(p_225314_, i, 0, j);

               for(int k = 0; p_225311_.m_7433_(blockpos$mutableblockpos, BlockBehaviour.BlockStateBase::m_60795_) && k < p_225312_.f_161287_; ++k) {
                  blockpos$mutableblockpos.m_122173_(direction);
               }

               for(int i1 = 0; p_225311_.m_7433_(blockpos$mutableblockpos, (p_204784_) -> {
                  return !p_204784_.m_60795_();
               }) && i1 < p_225312_.f_161287_; ++i1) {
                  blockpos$mutableblockpos.m_122173_(direction1);
               }

               blockpos$mutableblockpos1.m_122159_(blockpos$mutableblockpos, p_225312_.f_161284_.m_162107_());
               BlockState blockstate = p_225311_.m_8055_(blockpos$mutableblockpos1);
               if (p_225311_.m_46859_(blockpos$mutableblockpos) && blockstate.m_60783_(p_225311_, blockpos$mutableblockpos1, p_225312_.f_161284_.m_162107_().m_122424_())) {
                  int l = p_225312_.f_161285_.m_214085_(p_225313_) + (p_225312_.f_161286_ > 0.0F && p_225313_.m_188501_() < p_225312_.f_161286_ ? 1 : 0);
                  BlockPos blockpos = blockpos$mutableblockpos1.m_7949_();
                  boolean flag5 = this.m_225323_(p_225311_, p_225312_, p_225315_, p_225313_, blockpos$mutableblockpos1, l);
                  if (flag5) {
                     set.add(blockpos);
                  }
               }
            }
         }
      }

      return set;
   }

   protected void m_225330_(FeaturePlaceContext<VegetationPatchConfiguration> p_225331_, WorldGenLevel p_225332_, VegetationPatchConfiguration p_225333_, RandomSource p_225334_, Set<BlockPos> p_225335_, int p_225336_, int p_225337_) {
      for(BlockPos blockpos : p_225335_) {
         if (p_225333_.f_161288_ > 0.0F && p_225334_.m_188501_() < p_225333_.f_161288_) {
            this.m_213555_(p_225332_, p_225333_, p_225331_.m_159775_(), p_225334_, blockpos);
         }
      }

   }

   protected boolean m_213555_(WorldGenLevel p_225318_, VegetationPatchConfiguration p_225319_, ChunkGenerator p_225320_, RandomSource p_225321_, BlockPos p_225322_) {
      return p_225319_.f_161283_.m_203334_().m_226357_(p_225318_, p_225320_, p_225321_, p_225322_.m_121945_(p_225319_.f_161284_.m_162107_().m_122424_()));
   }

   protected boolean m_225323_(WorldGenLevel p_225324_, VegetationPatchConfiguration p_225325_, Predicate<BlockState> p_225326_, RandomSource p_225327_, BlockPos.MutableBlockPos p_225328_, int p_225329_) {
      for(int i = 0; i < p_225329_; ++i) {
         BlockState blockstate = p_225325_.f_161282_.m_213972_(p_225327_, p_225328_);
         BlockState blockstate1 = p_225324_.m_8055_(p_225328_);
         if (!blockstate.m_60713_(blockstate1.m_60734_())) {
            if (!p_225326_.test(blockstate1)) {
               return i != 0;
            }

            p_225324_.m_7731_(p_225328_, blockstate, 2);
            p_225328_.m_122173_(p_225325_.f_161284_.m_162107_());
         }
      }

      return true;
   }
}