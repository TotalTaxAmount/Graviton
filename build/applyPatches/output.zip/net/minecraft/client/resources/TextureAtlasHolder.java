package net.minecraft.client.resources;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.client.renderer.texture.SpriteLoader;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.PreparableReloadListener;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class TextureAtlasHolder implements PreparableReloadListener, AutoCloseable {
   private final TextureAtlas f_118884_;
   private final ResourceLocation f_260648_;

   public TextureAtlasHolder(TextureManager p_262057_, ResourceLocation p_261554_, ResourceLocation p_262147_) {
      this.f_260648_ = p_262147_;
      this.f_118884_ = new TextureAtlas(p_261554_);
      p_262057_.m_118495_(this.f_118884_.m_118330_(), this.f_118884_);
   }

   protected TextureAtlasSprite m_118901_(ResourceLocation p_118902_) {
      return this.f_118884_.m_118316_(p_118902_);
   }

   public final CompletableFuture<Void> m_5540_(PreparableReloadListener.PreparationBarrier p_249641_, ResourceManager p_250036_, ProfilerFiller p_249806_, ProfilerFiller p_250732_, Executor p_249427_, Executor p_250510_) {
      return SpriteLoader.m_245483_(this.f_118884_).m_260881_(p_250036_, this.f_260648_, 0, p_249427_).thenCompose(SpriteLoader.Preparations::m_246429_).thenCompose(p_249641_::m_6769_).thenAcceptAsync((p_249246_) -> {
         this.m_245256_(p_249246_, p_250732_);
      }, p_250510_);
   }

   private void m_245256_(SpriteLoader.Preparations p_252333_, ProfilerFiller p_250624_) {
      p_250624_.m_7242_();
      p_250624_.m_6180_("upload");
      this.f_118884_.m_247065_(p_252333_);
      p_250624_.m_7238_();
      p_250624_.m_7241_();
   }

   public void close() {
      this.f_118884_.m_118329_();
   }
}