package net.minecraft.client.resources.model;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonElement;
import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import com.mojang.math.Transformation;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import javax.annotation.Nullable;
import net.minecraft.Util;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.block.BlockModelShaper;
import net.minecraft.client.renderer.block.model.BlockModel;
import net.minecraft.client.renderer.block.model.BlockModelDefinition;
import net.minecraft.client.renderer.block.model.ItemModelGenerator;
import net.minecraft.client.renderer.block.model.multipart.MultiPart;
import net.minecraft.client.renderer.block.model.multipart.Selector;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.MissingTextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class ModelBakery {
   public static final Material f_119219_ = new Material(TextureAtlas.f_118259_, new ResourceLocation("block/fire_0"));
   public static final Material f_119220_ = new Material(TextureAtlas.f_118259_, new ResourceLocation("block/fire_1"));
   public static final Material f_119221_ = new Material(TextureAtlas.f_118259_, new ResourceLocation("block/lava_flow"));
   public static final Material f_119222_ = new Material(TextureAtlas.f_118259_, new ResourceLocation("block/water_flow"));
   public static final Material f_119223_ = new Material(TextureAtlas.f_118259_, new ResourceLocation("block/water_overlay"));
   public static final Material f_119224_ = new Material(Sheets.f_110737_, new ResourceLocation("entity/banner_base"));
   public static final Material f_119225_ = new Material(Sheets.f_110738_, new ResourceLocation("entity/shield_base"));
   public static final Material f_119226_ = new Material(Sheets.f_110738_, new ResourceLocation("entity/shield_base_nopattern"));
   public static final int f_174875_ = 10;
   public static final List<ResourceLocation> f_119227_ = IntStream.range(0, 10).mapToObj((p_119253_) -> {
      return new ResourceLocation("block/destroy_stage_" + p_119253_);
   }).collect(Collectors.toList());
   public static final List<ResourceLocation> f_119228_ = f_119227_.stream().map((p_119371_) -> {
      return new ResourceLocation("textures/" + p_119371_.m_135815_() + ".png");
   }).collect(Collectors.toList());
   public static final List<RenderType> f_119229_ = f_119228_.stream().map(RenderType::m_110494_).collect(Collectors.toList());
   static final int f_174876_ = -1;
   private static final int f_174877_ = 0;
   private static final Logger f_119235_ = LogUtils.getLogger();
   private static final String f_174878_ = "builtin/";
   private static final String f_174879_ = "builtin/generated";
   private static final String f_174880_ = "builtin/entity";
   private static final String f_174881_ = "missing";
   public static final ModelResourceLocation f_119230_ = ModelResourceLocation.m_245263_("builtin/missing", "missing");
   public static final FileToIdConverter f_244202_ = FileToIdConverter.m_246568_("blockstates");
   public static final FileToIdConverter f_244378_ = FileToIdConverter.m_246568_("models");
   @VisibleForTesting
   public static final String f_119231_ = ("{    'textures': {       'particle': '" + MissingTextureAtlasSprite.m_118071_().m_135815_() + "',       'missingno': '" + MissingTextureAtlasSprite.m_118071_().m_135815_() + "'    },    'elements': [         {  'from': [ 0, 0, 0 ],            'to': [ 16, 16, 16 ],            'faces': {                'down':  { 'uv': [ 0, 0, 16, 16 ], 'cullface': 'down',  'texture': '#missingno' },                'up':    { 'uv': [ 0, 0, 16, 16 ], 'cullface': 'up',    'texture': '#missingno' },                'north': { 'uv': [ 0, 0, 16, 16 ], 'cullface': 'north', 'texture': '#missingno' },                'south': { 'uv': [ 0, 0, 16, 16 ], 'cullface': 'south', 'texture': '#missingno' },                'west':  { 'uv': [ 0, 0, 16, 16 ], 'cullface': 'west',  'texture': '#missingno' },                'east':  { 'uv': [ 0, 0, 16, 16 ], 'cullface': 'east',  'texture': '#missingno' }            }        }    ]}").replace('\'', '"');
   private static final Map<String, String> f_119237_ = Maps.newHashMap(ImmutableMap.of("missing", f_119231_));
   private static final Splitter f_119238_ = Splitter.on(',');
   private static final Splitter f_119239_ = Splitter.on('=').limit(2);
   public static final BlockModel f_119232_ = Util.m_137469_(BlockModel.m_111463_("{\"gui_light\": \"front\"}"), (p_119359_) -> {
      p_119359_.f_111416_ = "generation marker";
   });
   public static final BlockModel f_119233_ = Util.m_137469_(BlockModel.m_111463_("{\"gui_light\": \"side\"}"), (p_119297_) -> {
      p_119297_.f_111416_ = "block entity marker";
   });
   private static final StateDefinition<Block, BlockState> f_119240_ = (new StateDefinition.Builder<Block, BlockState>(Blocks.f_50016_)).m_61104_(BooleanProperty.m_61465_("map")).m_61101_(Block::m_49966_, BlockState::new);
   static final ItemModelGenerator f_119241_ = new ItemModelGenerator();
   private static final Map<ResourceLocation, StateDefinition<Block, BlockState>> f_119242_ = ImmutableMap.of(new ResourceLocation("item_frame"), f_119240_, new ResourceLocation("glow_item_frame"), f_119240_);
   private final BlockColors f_119209_;
   private final Map<ResourceLocation, BlockModel> f_244132_;
   private final Map<ResourceLocation, List<ModelBakery.LoadedJson>> f_243866_;
   private final Set<ResourceLocation> f_119210_ = Sets.newHashSet();
   private final BlockModelDefinition.Context f_119211_ = new BlockModelDefinition.Context();
   private final Map<ResourceLocation, UnbakedModel> f_119212_ = Maps.newHashMap();
   final Map<ModelBakery.BakedCacheKey, BakedModel> f_119213_ = Maps.newHashMap();
   private final Map<ResourceLocation, UnbakedModel> f_119214_ = Maps.newHashMap();
   private final Map<ResourceLocation, BakedModel> f_119215_ = Maps.newHashMap();
   private int f_119217_ = 1;
   private final Object2IntMap<BlockState> f_119218_ = Util.m_137469_(new Object2IntOpenHashMap<>(), (p_119309_) -> {
      p_119309_.defaultReturnValue(-1);
   });

   public ModelBakery(BlockColors p_249183_, ProfilerFiller p_252014_, Map<ResourceLocation, BlockModel> p_251087_, Map<ResourceLocation, List<ModelBakery.LoadedJson>> p_250416_) {
      this.f_119209_ = p_249183_;
      this.f_244132_ = p_251087_;
      this.f_243866_ = p_250416_;
      p_252014_.m_6180_("missing_model");

      try {
         this.f_119212_.put(f_119230_, this.m_119364_(f_119230_));
         this.m_119306_(f_119230_);
      } catch (IOException ioexception) {
         f_119235_.error("Error loading missing model, should never happen :(", (Throwable)ioexception);
         throw new RuntimeException(ioexception);
      }

      p_252014_.m_6182_("static_definitions");
      f_119242_.forEach((p_119347_, p_119348_) -> {
         p_119348_.m_61056_().forEach((p_174905_) -> {
            this.m_119306_(BlockModelShaper.m_110889_(p_119347_, p_174905_));
         });
      });
      p_252014_.m_6182_("blocks");

      for(Block block : BuiltInRegistries.f_256975_) {
         block.m_49965_().m_61056_().forEach((p_119264_) -> {
            this.m_119306_(BlockModelShaper.m_110895_(p_119264_));
         });
      }

      p_252014_.m_6182_("items");

      for(ResourceLocation resourcelocation : BuiltInRegistries.f_257033_.m_6566_()) {
         this.m_119306_(new ModelResourceLocation(resourcelocation, "inventory"));
      }

      p_252014_.m_6182_("special");
      this.m_119306_(ItemRenderer.f_244055_);
      this.m_119306_(ItemRenderer.f_243706_);
      this.f_119214_.values().forEach((p_247954_) -> {
         p_247954_.m_5500_(this::m_119341_);
      });
      p_252014_.m_7238_();
   }

   public void m_245909_(BiFunction<ResourceLocation, Material, TextureAtlasSprite> p_248669_) {
      this.f_119214_.keySet().forEach((p_247958_) -> {
         BakedModel bakedmodel = null;

         try {
            bakedmodel = (new ModelBakery.ModelBakerImpl(p_248669_, p_247958_)).m_245240_(p_247958_, BlockModelRotation.X0_Y0);
         } catch (Exception exception) {
            f_119235_.warn("Unable to bake model: '{}': {}", p_247958_, exception);
         }

         if (bakedmodel != null) {
            this.f_119215_.put(p_247958_, bakedmodel);
         }

      });
   }

   private static Predicate<BlockState> m_119273_(StateDefinition<Block, BlockState> p_119274_, String p_119275_) {
      Map<Property<?>, Comparable<?>> map = Maps.newHashMap();

      for(String s : f_119238_.split(p_119275_)) {
         Iterator<String> iterator = f_119239_.split(s).iterator();
         if (iterator.hasNext()) {
            String s1 = iterator.next();
            Property<?> property = p_119274_.m_61081_(s1);
            if (property != null && iterator.hasNext()) {
               String s2 = iterator.next();
               Comparable<?> comparable = m_119276_(property, s2);
               if (comparable == null) {
                  throw new RuntimeException("Unknown value: '" + s2 + "' for blockstate property: '" + s1 + "' " + property.m_6908_());
               }

               map.put(property, comparable);
            } else if (!s1.isEmpty()) {
               throw new RuntimeException("Unknown blockstate property: '" + s1 + "'");
            }
         }
      }

      Block block = p_119274_.m_61091_();
      return (p_119262_) -> {
         if (p_119262_ != null && p_119262_.m_60713_(block)) {
            for(Map.Entry<Property<?>, Comparable<?>> entry : map.entrySet()) {
               if (!Objects.equals(p_119262_.m_61143_(entry.getKey()), entry.getValue())) {
                  return false;
               }
            }

            return true;
         } else {
            return false;
         }
      };
   }

   @Nullable
   static <T extends Comparable<T>> T m_119276_(Property<T> p_119277_, String p_119278_) {
      return p_119277_.m_6215_(p_119278_).orElse((T)null);
   }

   public UnbakedModel m_119341_(ResourceLocation p_119342_) {
      if (this.f_119212_.containsKey(p_119342_)) {
         return this.f_119212_.get(p_119342_);
      } else if (this.f_119210_.contains(p_119342_)) {
         throw new IllegalStateException("Circular reference while loading " + p_119342_);
      } else {
         this.f_119210_.add(p_119342_);
         UnbakedModel unbakedmodel = this.f_119212_.get(f_119230_);

         while(!this.f_119210_.isEmpty()) {
            ResourceLocation resourcelocation = this.f_119210_.iterator().next();

            try {
               if (!this.f_119212_.containsKey(resourcelocation)) {
                  this.m_119362_(resourcelocation);
               }
            } catch (ModelBakery.BlockStateDefinitionException modelbakery$blockstatedefinitionexception) {
               f_119235_.warn(modelbakery$blockstatedefinitionexception.getMessage());
               this.f_119212_.put(resourcelocation, unbakedmodel);
            } catch (Exception exception) {
               f_119235_.warn("Unable to load model: '{}' referenced from: {}: {}", resourcelocation, p_119342_, exception);
               this.f_119212_.put(resourcelocation, unbakedmodel);
            } finally {
               this.f_119210_.remove(resourcelocation);
            }
         }

         return this.f_119212_.getOrDefault(p_119342_, unbakedmodel);
      }
   }

   private void m_119362_(ResourceLocation p_119363_) throws Exception {
      if (!(p_119363_ instanceof ModelResourceLocation modelresourcelocation)) {
         this.m_119352_(p_119363_, this.m_119364_(p_119363_));
      } else {
         if (Objects.equals(modelresourcelocation.m_119448_(), "inventory")) {
            ResourceLocation resourcelocation = p_119363_.m_246208_("item/");
            BlockModel blockmodel = this.m_119364_(resourcelocation);
            this.m_119352_(modelresourcelocation, blockmodel);
            this.f_119212_.put(resourcelocation, blockmodel);
         } else {
            ResourceLocation resourcelocation2 = new ResourceLocation(p_119363_.m_135827_(), p_119363_.m_135815_());
            StateDefinition<Block, BlockState> statedefinition = Optional.ofNullable(f_119242_.get(resourcelocation2)).orElseGet(() -> {
               return BuiltInRegistries.f_256975_.m_7745_(resourcelocation2).m_49965_();
            });
            this.f_119211_.m_111552_(statedefinition);
            List<Property<?>> list = ImmutableList.copyOf(this.f_119209_.m_92575_(statedefinition.m_61091_()));
            ImmutableList<BlockState> immutablelist = statedefinition.m_61056_();
            Map<ModelResourceLocation, BlockState> map = Maps.newHashMap();
            immutablelist.forEach((p_119330_) -> {
               map.put(BlockModelShaper.m_110889_(resourcelocation2, p_119330_), p_119330_);
            });
            Map<BlockState, Pair<UnbakedModel, Supplier<ModelBakery.ModelGroupKey>>> map1 = Maps.newHashMap();
            ResourceLocation resourcelocation1 = f_244202_.m_245698_(p_119363_);
            UnbakedModel unbakedmodel = this.f_119212_.get(f_119230_);
            ModelBakery.ModelGroupKey modelbakery$modelgroupkey = new ModelBakery.ModelGroupKey(ImmutableList.of(unbakedmodel), ImmutableList.of());
            Pair<UnbakedModel, Supplier<ModelBakery.ModelGroupKey>> pair = Pair.of(unbakedmodel, () -> {
               return modelbakery$modelgroupkey;
            });

            try {
               for(Pair<String, BlockModelDefinition> pair1 : this.f_243866_.getOrDefault(resourcelocation1, List.of()).stream().map((p_247956_) -> {
                  try {
                     return Pair.of(p_247956_.f_243774_, BlockModelDefinition.m_247114_(this.f_119211_, p_247956_.f_244212_));
                  } catch (Exception exception1) {
                     throw new ModelBakery.BlockStateDefinitionException(String.format(Locale.ROOT, "Exception loading blockstate definition: '%s' in resourcepack: '%s': %s", resourcelocation1, p_247956_.f_243774_, exception1.getMessage()));
                  }
               }).toList()) {
                  BlockModelDefinition blockmodeldefinition = pair1.getSecond();
                  Map<BlockState, Pair<UnbakedModel, Supplier<ModelBakery.ModelGroupKey>>> map2 = Maps.newIdentityHashMap();
                  MultiPart multipart;
                  if (blockmodeldefinition.m_111543_()) {
                     multipart = blockmodeldefinition.m_111544_();
                     immutablelist.forEach((p_119326_) -> {
                        map2.put(p_119326_, Pair.of(multipart, () -> {
                           return ModelBakery.ModelGroupKey.m_119379_(p_119326_, multipart, list);
                        }));
                     });
                  } else {
                     multipart = null;
                  }

                  blockmodeldefinition.m_111539_().forEach((p_119289_, p_119290_) -> {
                     try {
                        immutablelist.stream().filter(m_119273_(statedefinition, p_119289_)).forEach((p_174902_) -> {
                           Pair<UnbakedModel, Supplier<ModelBakery.ModelGroupKey>> pair2 = map2.put(p_174902_, Pair.of(p_119290_, () -> {
                              return ModelBakery.ModelGroupKey.m_119383_(p_174902_, p_119290_, list);
                           }));
                           if (pair2 != null && pair2.getFirst() != multipart) {
                              map2.put(p_174902_, pair);
                              throw new RuntimeException("Overlapping definition with: " + (String)blockmodeldefinition.m_111539_().entrySet().stream().filter((p_174892_) -> {
                                 return p_174892_.getValue() == pair2.getFirst();
                              }).findFirst().get().getKey());
                           }
                        });
                     } catch (Exception exception1) {
                        f_119235_.warn("Exception loading blockstate definition: '{}' in resourcepack: '{}' for variant: '{}': {}", resourcelocation1, pair1.getFirst(), p_119289_, exception1.getMessage());
                     }

                  });
                  map1.putAll(map2);
               }
            } catch (ModelBakery.BlockStateDefinitionException modelbakery$blockstatedefinitionexception) {
               throw modelbakery$blockstatedefinitionexception;
            } catch (Exception exception) {
               throw new ModelBakery.BlockStateDefinitionException(String.format(Locale.ROOT, "Exception loading blockstate definition: '%s': %s", resourcelocation1, exception));
            } finally {
               Map<ModelBakery.ModelGroupKey, Set<BlockState>> map3 = Maps.newHashMap();
               map.forEach((p_119336_, p_119337_) -> {
                  Pair<UnbakedModel, Supplier<ModelBakery.ModelGroupKey>> pair2 = map1.get(p_119337_);
                  if (pair2 == null) {
                     f_119235_.warn("Exception loading blockstate definition: '{}' missing model for variant: '{}'", resourcelocation1, p_119336_);
                     pair2 = pair;
                  }

                  this.m_119352_(p_119336_, pair2.getFirst());

                  try {
                     ModelBakery.ModelGroupKey modelbakery$modelgroupkey1 = pair2.getSecond().get();
                     map3.computeIfAbsent(modelbakery$modelgroupkey1, (p_174894_) -> {
                        return Sets.newIdentityHashSet();
                     }).add(p_119337_);
                  } catch (Exception exception1) {
                     f_119235_.warn("Exception evaluating model definition: '{}'", p_119336_, exception1);
                  }

               });
               map3.forEach((p_119304_, p_119305_) -> {
                  Iterator<BlockState> iterator = p_119305_.iterator();

                  while(iterator.hasNext()) {
                     BlockState blockstate = iterator.next();
                     if (blockstate.m_60799_() != RenderShape.MODEL) {
                        iterator.remove();
                        this.f_119218_.put(blockstate, 0);
                     }
                  }

                  if (p_119305_.size() > 1) {
                     this.m_119310_(p_119305_);
                  }

               });
            }
         }

      }
   }

   private void m_119352_(ResourceLocation p_119353_, UnbakedModel p_119354_) {
      this.f_119212_.put(p_119353_, p_119354_);
      this.f_119210_.addAll(p_119354_.m_7970_());
   }

   private void m_119306_(ModelResourceLocation p_119307_) {
      UnbakedModel unbakedmodel = this.m_119341_(p_119307_);
      this.f_119212_.put(p_119307_, unbakedmodel);
      this.f_119214_.put(p_119307_, unbakedmodel);
   }

   private void m_119310_(Iterable<BlockState> p_119311_) {
      int i = this.f_119217_++;
      p_119311_.forEach((p_119256_) -> {
         this.f_119218_.put(p_119256_, i);
      });
   }

   private BlockModel m_119364_(ResourceLocation p_119365_) throws IOException {
      String s = p_119365_.m_135815_();
      if ("builtin/generated".equals(s)) {
         return f_119232_;
      } else if ("builtin/entity".equals(s)) {
         return f_119233_;
      } else if (s.startsWith("builtin/")) {
         String s1 = s.substring("builtin/".length());
         String s2 = f_119237_.get(s1);
         if (s2 == null) {
            throw new FileNotFoundException(p_119365_.toString());
         } else {
            Reader reader = new StringReader(s2);
            BlockModel blockmodel1 = BlockModel.m_111461_(reader);
            blockmodel1.f_111416_ = p_119365_.toString();
            return blockmodel1;
         }
      } else {
         ResourceLocation resourcelocation = f_244378_.m_245698_(p_119365_);
         BlockModel blockmodel = this.f_244132_.get(resourcelocation);
         if (blockmodel == null) {
            throw new FileNotFoundException(resourcelocation.toString());
         } else {
            blockmodel.f_111416_ = p_119365_.toString();
            return blockmodel;
         }
      }
   }

   public Map<ResourceLocation, BakedModel> m_119251_() {
      return this.f_119215_;
   }

   public Object2IntMap<BlockState> m_119355_() {
      return this.f_119218_;
   }

   @OnlyIn(Dist.CLIENT)
   static record BakedCacheKey(ResourceLocation f_243934_, Transformation f_243798_, boolean f_243915_) {
   }

   @OnlyIn(Dist.CLIENT)
   static class BlockStateDefinitionException extends RuntimeException {
      public BlockStateDefinitionException(String p_119373_) {
         super(p_119373_);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static record LoadedJson(String f_243774_, JsonElement f_244212_) {
   }

   @OnlyIn(Dist.CLIENT)
   class ModelBakerImpl implements ModelBaker {
      private final Function<Material, TextureAtlasSprite> f_243920_;

      ModelBakerImpl(BiFunction<ResourceLocation, Material, TextureAtlasSprite> p_249651_, ResourceLocation p_251408_) {
         this.f_243920_ = (p_250859_) -> {
            return p_249651_.apply(p_251408_, p_250859_);
         };
      }

      public UnbakedModel m_245361_(ResourceLocation p_248568_) {
         return ModelBakery.this.m_119341_(p_248568_);
      }

      public BakedModel m_245240_(ResourceLocation p_252176_, ModelState p_249765_) {
         ModelBakery.BakedCacheKey modelbakery$bakedcachekey = new ModelBakery.BakedCacheKey(p_252176_, p_249765_.m_6189_(), p_249765_.m_7538_());
         BakedModel bakedmodel = ModelBakery.this.f_119213_.get(modelbakery$bakedcachekey);
         if (bakedmodel != null) {
            return bakedmodel;
         } else {
            UnbakedModel unbakedmodel = this.m_245361_(p_252176_);
            if (unbakedmodel instanceof BlockModel) {
               BlockModel blockmodel = (BlockModel)unbakedmodel;
               if (blockmodel.m_111490_() == ModelBakery.f_119232_) {
                  return ModelBakery.f_119241_.m_111670_(this.f_243920_, blockmodel).m_111449_(this, blockmodel, this.f_243920_, p_249765_, p_252176_, false);
               }
            }

            BakedModel bakedmodel1 = unbakedmodel.m_7611_(this, this.f_243920_, p_249765_, p_252176_);
            ModelBakery.this.f_119213_.put(modelbakery$bakedcachekey, bakedmodel1);
            return bakedmodel1;
         }
      }
   }

   @OnlyIn(Dist.CLIENT)
   static class ModelGroupKey {
      private final List<UnbakedModel> f_119374_;
      private final List<Object> f_119375_;

      public ModelGroupKey(List<UnbakedModel> p_119377_, List<Object> p_119378_) {
         this.f_119374_ = p_119377_;
         this.f_119375_ = p_119378_;
      }

      public boolean equals(Object p_119395_) {
         if (this == p_119395_) {
            return true;
         } else if (!(p_119395_ instanceof ModelBakery.ModelGroupKey)) {
            return false;
         } else {
            ModelBakery.ModelGroupKey modelbakery$modelgroupkey = (ModelBakery.ModelGroupKey)p_119395_;
            return Objects.equals(this.f_119374_, modelbakery$modelgroupkey.f_119374_) && Objects.equals(this.f_119375_, modelbakery$modelgroupkey.f_119375_);
         }
      }

      public int hashCode() {
         return 31 * this.f_119374_.hashCode() + this.f_119375_.hashCode();
      }

      public static ModelBakery.ModelGroupKey m_119379_(BlockState p_119380_, MultiPart p_119381_, Collection<Property<?>> p_119382_) {
         StateDefinition<Block, BlockState> statedefinition = p_119380_.m_60734_().m_49965_();
         List<UnbakedModel> list = p_119381_.m_111967_().stream().filter((p_119393_) -> {
            return p_119393_.m_112021_(statedefinition).test(p_119380_);
         }).map(Selector::m_112020_).collect(ImmutableList.toImmutableList());
         List<Object> list1 = m_119387_(p_119380_, p_119382_);
         return new ModelBakery.ModelGroupKey(list, list1);
      }

      public static ModelBakery.ModelGroupKey m_119383_(BlockState p_119384_, UnbakedModel p_119385_, Collection<Property<?>> p_119386_) {
         List<Object> list = m_119387_(p_119384_, p_119386_);
         return new ModelBakery.ModelGroupKey(ImmutableList.of(p_119385_), list);
      }

      private static List<Object> m_119387_(BlockState p_119388_, Collection<Property<?>> p_119389_) {
         return p_119389_.stream().map(p_119388_::m_61143_).collect(ImmutableList.toImmutableList());
      }
   }
}