package net.minecraft.client.renderer.texture.atlas;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.List;
import net.minecraft.client.renderer.texture.atlas.sources.DirectoryLister;
import net.minecraft.client.renderer.texture.atlas.sources.PalettedPermutations;
import net.minecraft.client.renderer.texture.atlas.sources.SingleFile;
import net.minecraft.client.renderer.texture.atlas.sources.SourceFilter;
import net.minecraft.client.renderer.texture.atlas.sources.Unstitcher;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class SpriteSources {
   private static final BiMap<ResourceLocation, SpriteSourceType> f_260548_ = HashBiMap.create();
   public static final SpriteSourceType f_260457_ = m_260887_("single", SingleFile.f_260609_);
   public static final SpriteSourceType f_260490_ = m_260887_("directory", DirectoryLister.f_260655_);
   public static final SpriteSourceType f_260627_ = m_260887_("filter", SourceFilter.f_260515_);
   public static final SpriteSourceType f_260546_ = m_260887_("unstitch", Unstitcher.f_260484_);
   public static final SpriteSourceType f_266099_ = m_260887_("paletted_permutations", PalettedPermutations.f_266028_);
   public static Codec<SpriteSourceType> f_260540_ = ResourceLocation.f_135803_.flatXmap((p_274717_) -> {
      SpriteSourceType spritesourcetype = f_260548_.get(p_274717_);
      return spritesourcetype != null ? DataResult.success(spritesourcetype) : DataResult.error(() -> {
         return "Unknown type " + p_274717_;
      });
   }, (p_274716_) -> {
      ResourceLocation resourcelocation = f_260548_.inverse().get(p_274716_);
      return p_274716_ != null ? DataResult.success(resourcelocation) : DataResult.error(() -> {
         return "Unknown type " + resourcelocation;
      });
   });
   public static Codec<SpriteSource> f_260500_ = f_260540_.dispatch(SpriteSource::m_260850_, SpriteSourceType::f_260449_);
   public static Codec<List<SpriteSource>> f_260551_ = f_260500_.listOf().fieldOf("sources").codec();

   private static SpriteSourceType m_260887_(String p_262175_, Codec<? extends SpriteSource> p_261464_) {
      SpriteSourceType spritesourcetype = new SpriteSourceType(p_261464_);
      ResourceLocation resourcelocation = new ResourceLocation(p_262175_);
      SpriteSourceType spritesourcetype1 = f_260548_.putIfAbsent(resourcelocation, spritesourcetype);
      if (spritesourcetype1 != null) {
         throw new IllegalStateException("Duplicate registration " + resourcelocation);
      } else {
         return spritesourcetype;
      }
   }
}