package net.minecraft.client.gui.components.tabs;

import java.util.Objects;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class TabManager {
   private final Consumer<AbstractWidget> f_267431_;
   private final Consumer<AbstractWidget> f_267452_;
   @Nullable
   private Tab f_267400_;
   @Nullable
   private ScreenRectangle f_267478_;

   public TabManager(Consumer<AbstractWidget> p_268279_, Consumer<AbstractWidget> p_268196_) {
      this.f_267431_ = p_268279_;
      this.f_267452_ = p_268196_;
   }

   public void m_267817_(ScreenRectangle p_268042_) {
      this.f_267478_ = p_268042_;
      Tab tab = this.m_267695_();
      if (tab != null) {
         tab.m_267697_(p_268042_);
      }

   }

   public void m_276088_(Tab p_276109_, boolean p_276120_) {
      if (!Objects.equals(this.f_267400_, p_276109_)) {
         if (this.f_267400_ != null) {
            this.f_267400_.m_267609_(this.f_267452_);
         }

         this.f_267400_ = p_276109_;
         p_276109_.m_267609_(this.f_267431_);
         if (this.f_267478_ != null) {
            p_276109_.m_267697_(this.f_267478_);
         }

         if (p_276120_) {
            Minecraft.m_91087_().m_91106_().m_120367_(SimpleSoundInstance.m_263171_(SoundEvents.f_12490_, 1.0F));
         }
      }

   }

   @Nullable
   public Tab m_267695_() {
      return this.f_267400_;
   }

   public void m_267621_() {
      Tab tab = this.m_267695_();
      if (tab != null) {
         tab.m_267681_();
      }

   }
}