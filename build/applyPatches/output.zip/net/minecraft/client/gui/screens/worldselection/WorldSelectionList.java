package net.minecraft.client.gui.screens.worldselection;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.google.common.hash.Hashing;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.CrashReport;
import net.minecraft.SharedConstants;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.components.toasts.SystemToast;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.AlertScreen;
import net.minecraft.client.gui.screens.BackupConfirmScreen;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.client.gui.screens.ErrorScreen;
import net.minecraft.client.gui.screens.GenericDirtMessageScreen;
import net.minecraft.client.gui.screens.LoadingDotsText;
import net.minecraft.client.gui.screens.ProgressScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.LevelSettings;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.level.storage.LevelStorageException;
import net.minecraft.world.level.storage.LevelStorageSource;
import net.minecraft.world.level.storage.LevelSummary;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class WorldSelectionList extends ObjectSelectionList<WorldSelectionList.Entry> {
   static final Logger f_101645_ = LogUtils.getLogger();
   static final DateFormat f_101646_ = new SimpleDateFormat();
   static final ResourceLocation f_101647_ = new ResourceLocation("textures/misc/unknown_server.png");
   static final ResourceLocation f_101648_ = new ResourceLocation("textures/gui/world_selection.png");
   static final Component f_101649_ = Component.m_237115_("selectWorld.tooltip.fromNewerVersion1").m_130940_(ChatFormatting.RED);
   static final Component f_101650_ = Component.m_237115_("selectWorld.tooltip.fromNewerVersion2").m_130940_(ChatFormatting.RED);
   static final Component f_101651_ = Component.m_237115_("selectWorld.tooltip.snapshot1").m_130940_(ChatFormatting.GOLD);
   static final Component f_101652_ = Component.m_237115_("selectWorld.tooltip.snapshot2").m_130940_(ChatFormatting.GOLD);
   static final Component f_101653_ = Component.m_237115_("selectWorld.locked").m_130940_(ChatFormatting.RED);
   static final Component f_194113_ = Component.m_237115_("selectWorld.conversion.tooltip").m_130940_(ChatFormatting.RED);
   private final SelectWorldScreen f_101654_;
   private CompletableFuture<List<LevelSummary>> f_238666_;
   @Nullable
   private List<LevelSummary> f_238575_;
   private String f_238624_;
   private final WorldSelectionList.LoadingHeader f_233184_;

   public WorldSelectionList(SelectWorldScreen p_239540_, Minecraft p_239541_, int p_239542_, int p_239543_, int p_239544_, int p_239545_, int p_239546_, String p_239547_, @Nullable WorldSelectionList p_239548_) {
      super(p_239541_, p_239542_, p_239543_, p_239544_, p_239545_, p_239546_);
      this.f_101654_ = p_239540_;
      this.f_233184_ = new WorldSelectionList.LoadingHeader(p_239541_);
      this.f_238624_ = p_239547_;
      if (p_239548_ != null) {
         this.f_238666_ = p_239548_.f_238666_;
      } else {
         this.f_238666_ = this.m_233213_();
      }

      this.m_239664_(this.m_239987_());
   }

   @Nullable
   private List<LevelSummary> m_239987_() {
      try {
         return this.f_238666_.getNow((List<LevelSummary>)null);
      } catch (CancellationException | CompletionException completionexception) {
         return null;
      }
   }

   void m_233206_() {
      this.f_238666_ = this.m_233213_();
   }

   public void m_86412_(PoseStack p_239123_, int p_239124_, int p_239125_, float p_239126_) {
      List<LevelSummary> list = this.m_239987_();
      if (list != this.f_238575_) {
         this.m_239664_(list);
      }

      super.m_86412_(p_239123_, p_239124_, p_239125_, p_239126_);
   }

   private void m_239664_(@Nullable List<LevelSummary> p_239665_) {
      if (p_239665_ == null) {
         this.m_233214_();
      } else {
         this.m_233198_(this.f_238624_, p_239665_);
      }

      this.f_238575_ = p_239665_;
   }

   public void m_239900_(String p_239901_) {
      if (this.f_238575_ != null && !p_239901_.equals(this.f_238624_)) {
         this.m_233198_(p_239901_, this.f_238575_);
      }

      this.f_238624_ = p_239901_;
   }

   private CompletableFuture<List<LevelSummary>> m_233213_() {
      LevelStorageSource.LevelCandidates levelstoragesource$levelcandidates;
      try {
         levelstoragesource$levelcandidates = this.f_93386_.m_91392_().m_230833_();
      } catch (LevelStorageException levelstorageexception) {
         f_101645_.error("Couldn't load level list", (Throwable)levelstorageexception);
         this.m_233211_(levelstorageexception.m_230806_());
         return CompletableFuture.completedFuture(List.of());
      }

      if (levelstoragesource$levelcandidates.m_230843_()) {
         CreateWorldScreen.m_232896_(this.f_93386_, (Screen)null);
         return CompletableFuture.completedFuture(List.of());
      } else {
         return this.f_93386_.m_91392_().m_230813_(levelstoragesource$levelcandidates).exceptionally((p_233202_) -> {
            this.f_93386_.m_231412_(CrashReport.m_127521_(p_233202_, "Couldn't load level list"));
            return List.of();
         });
      }
   }

   private void m_233198_(String p_233199_, List<LevelSummary> p_233200_) {
      this.m_93516_();
      p_233199_ = p_233199_.toLowerCase(Locale.ROOT);

      for(LevelSummary levelsummary : p_233200_) {
         if (this.m_233195_(p_233199_, levelsummary)) {
            this.m_7085_(new WorldSelectionList.WorldListEntry(this, levelsummary));
         }
      }

      this.m_233215_();
   }

   private boolean m_233195_(String p_233196_, LevelSummary p_233197_) {
      return p_233197_.m_78361_().toLowerCase(Locale.ROOT).contains(p_233196_) || p_233197_.m_78358_().toLowerCase(Locale.ROOT).contains(p_233196_);
   }

   private void m_233214_() {
      this.m_93516_();
      this.m_7085_(this.f_233184_);
      this.m_233215_();
   }

   private void m_233215_() {
      this.f_101654_.m_169407_(true);
   }

   private void m_233211_(Component p_233212_) {
      this.f_93386_.m_91152_(new ErrorScreen(Component.m_237115_("selectWorld.unable_to_load"), p_233212_));
   }

   protected int m_5756_() {
      return super.m_5756_() + 20;
   }

   public int m_5759_() {
      return super.m_5759_() + 50;
   }

   public void m_6987_(@Nullable WorldSelectionList.Entry p_233190_) {
      super.m_6987_(p_233190_);
      this.f_101654_.m_276090_(p_233190_ != null && p_233190_.m_214209_(), p_233190_ != null);
   }

   public Optional<WorldSelectionList.WorldListEntry> m_101684_() {
      WorldSelectionList.Entry worldselectionlist$entry = this.m_93511_();
      if (worldselectionlist$entry instanceof WorldSelectionList.WorldListEntry worldselectionlist$worldlistentry) {
         return Optional.of(worldselectionlist$worldlistentry);
      } else {
         return Optional.empty();
      }
   }

   public SelectWorldScreen m_101685_() {
      return this.f_101654_;
   }

   public void m_142291_(NarrationElementOutput p_233188_) {
      if (this.m_6702_().contains(this.f_233184_)) {
         this.f_233184_.m_142291_(p_233188_);
      } else {
         super.m_142291_(p_233188_);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public abstract static class Entry extends ObjectSelectionList.Entry<WorldSelectionList.Entry> implements AutoCloseable {
      public abstract boolean m_214209_();

      public void close() {
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class LoadingHeader extends WorldSelectionList.Entry {
      private static final Component f_233218_ = Component.m_237115_("selectWorld.loading_list");
      private final Minecraft f_233219_;

      public LoadingHeader(Minecraft p_233222_) {
         this.f_233219_ = p_233222_;
      }

      public void m_6311_(PoseStack p_233225_, int p_233226_, int p_233227_, int p_233228_, int p_233229_, int p_233230_, int p_233231_, int p_233232_, boolean p_233233_, float p_233234_) {
         int i = (this.f_233219_.f_91080_.f_96543_ - this.f_233219_.f_91062_.m_92852_(f_233218_)) / 2;
         int j = p_233227_ + (p_233230_ - 9) / 2;
         this.f_233219_.f_91062_.m_92889_(p_233225_, f_233218_, (float)i, (float)j, 16777215);
         String s = LoadingDotsText.m_232744_(Util.m_137550_());
         int k = (this.f_233219_.f_91080_.f_96543_ - this.f_233219_.f_91062_.m_92895_(s)) / 2;
         int l = j + 9;
         this.f_233219_.f_91062_.m_92883_(p_233225_, s, (float)k, (float)l, 8421504);
      }

      public Component m_142172_() {
         return f_233218_;
      }

      public boolean m_214209_() {
         return false;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public final class WorldListEntry extends WorldSelectionList.Entry implements AutoCloseable {
      private static final int f_170312_ = 32;
      private static final int f_170313_ = 32;
      private static final int f_170314_ = 0;
      private static final int f_170315_ = 32;
      private static final int f_170316_ = 64;
      private static final int f_170317_ = 96;
      private static final int f_170318_ = 0;
      private static final int f_170319_ = 32;
      private final Minecraft f_101693_;
      private final SelectWorldScreen f_101694_;
      private final LevelSummary f_101695_;
      private final ResourceLocation f_101696_;
      @Nullable
      private Path f_101697_;
      @Nullable
      private final DynamicTexture f_101698_;
      private long f_101699_;

      public WorldListEntry(WorldSelectionList p_101702_, LevelSummary p_101703_) {
         this.f_101693_ = p_101702_.f_93386_;
         this.f_101694_ = p_101702_.m_101685_();
         this.f_101695_ = p_101703_;
         String s = p_101703_.m_78358_();
         this.f_101696_ = new ResourceLocation("minecraft", "worlds/" + Util.m_137483_(s, ResourceLocation::m_135828_) + "/" + Hashing.sha1().hashUnencodedChars(s) + "/icon");
         this.f_101697_ = p_101703_.m_230875_();
         if (!Files.isRegularFile(this.f_101697_)) {
            this.f_101697_ = null;
         }

         this.f_101698_ = this.m_101746_();
      }

      public Component m_142172_() {
         Component component = Component.m_237110_("narrator.select.world", this.f_101695_.m_78361_(), new Date(this.f_101695_.m_78366_()), this.f_101695_.m_78368_() ? Component.m_237115_("gameMode.hardcore") : Component.m_237115_("gameMode." + this.f_101695_.m_78367_().m_46405_()), this.f_101695_.m_78369_() ? Component.m_237115_("selectWorld.cheats") : CommonComponents.f_237098_, this.f_101695_.m_78370_());
         Component component1;
         if (this.f_101695_.m_78375_()) {
            component1 = CommonComponents.m_267603_(component, WorldSelectionList.f_101653_);
         } else {
            component1 = component;
         }

         return Component.m_237110_("narrator.select", component1);
      }

      public void m_6311_(PoseStack p_101721_, int p_101722_, int p_101723_, int p_101724_, int p_101725_, int p_101726_, int p_101727_, int p_101728_, boolean p_101729_, float p_101730_) {
         String s = this.f_101695_.m_78361_();
         String s1 = this.f_101695_.m_78358_() + " (" + WorldSelectionList.f_101646_.format(new Date(this.f_101695_.m_78366_())) + ")";
         if (StringUtils.isEmpty(s)) {
            s = I18n.m_118938_("selectWorld.world") + " " + (p_101722_ + 1);
         }

         Component component = this.f_101695_.m_78376_();
         this.f_101693_.f_91062_.m_92883_(p_101721_, s, (float)(p_101724_ + 32 + 3), (float)(p_101723_ + 1), 16777215);
         this.f_101693_.f_91062_.m_92883_(p_101721_, s1, (float)(p_101724_ + 32 + 3), (float)(p_101723_ + 9 + 3), 8421504);
         this.f_101693_.f_91062_.m_92889_(p_101721_, component, (float)(p_101724_ + 32 + 3), (float)(p_101723_ + 9 + 9 + 3), 8421504);
         RenderSystem.m_157456_(0, this.f_101698_ != null ? this.f_101696_ : WorldSelectionList.f_101647_);
         RenderSystem.m_69478_();
         GuiComponent.m_93133_(p_101721_, p_101724_, p_101723_, 0.0F, 0.0F, 32, 32, 32, 32);
         RenderSystem.m_69461_();
         if (this.f_101693_.f_91066_.m_231828_().m_231551_() || p_101729_) {
            RenderSystem.m_157456_(0, WorldSelectionList.f_101648_);
            GuiComponent.m_93172_(p_101721_, p_101724_, p_101723_, p_101724_ + 32, p_101723_ + 32, -1601138544);
            int i = p_101727_ - p_101724_;
            boolean flag = i < 32;
            int j = flag ? 32 : 0;
            if (this.f_101695_.m_78375_()) {
               GuiComponent.m_93133_(p_101721_, p_101724_, p_101723_, 96.0F, (float)j, 32, 32, 256, 256);
               if (flag) {
                  this.f_101694_.m_257959_(this.f_101693_.f_91062_.m_92923_(WorldSelectionList.f_101653_, 175));
               }
            } else if (this.f_101695_.m_193020_()) {
               GuiComponent.m_93133_(p_101721_, p_101724_, p_101723_, 96.0F, (float)j, 32, 32, 256, 256);
               if (flag) {
                  this.f_101694_.m_257959_(this.f_101693_.f_91062_.m_92923_(WorldSelectionList.f_194113_, 175));
               }
            } else if (this.f_101695_.m_78372_()) {
               GuiComponent.m_93133_(p_101721_, p_101724_, p_101723_, 32.0F, (float)j, 32, 32, 256, 256);
               if (this.f_101695_.m_78373_()) {
                  GuiComponent.m_93133_(p_101721_, p_101724_, p_101723_, 96.0F, (float)j, 32, 32, 256, 256);
                  if (flag) {
                     this.f_101694_.m_257959_(ImmutableList.of(WorldSelectionList.f_101649_.m_7532_(), WorldSelectionList.f_101650_.m_7532_()));
                  }
               } else if (!SharedConstants.m_183709_().m_132498_()) {
                  GuiComponent.m_93133_(p_101721_, p_101724_, p_101723_, 64.0F, (float)j, 32, 32, 256, 256);
                  if (flag) {
                     this.f_101694_.m_257959_(ImmutableList.of(WorldSelectionList.f_101651_.m_7532_(), WorldSelectionList.f_101652_.m_7532_()));
                  }
               }
            } else {
               GuiComponent.m_93133_(p_101721_, p_101724_, p_101723_, 0.0F, (float)j, 32, 32, 256, 256);
            }
         }

      }

      public boolean m_6375_(double p_101706_, double p_101707_, int p_101708_) {
         if (this.f_101695_.m_164916_()) {
            return true;
         } else {
            WorldSelectionList.this.m_6987_((WorldSelectionList.Entry)this);
            if (p_101706_ - (double)WorldSelectionList.this.m_5747_() <= 32.0D) {
               this.m_101704_();
               return true;
            } else if (Util.m_137550_() - this.f_101699_ < 250L) {
               this.m_101704_();
               return true;
            } else {
               this.f_101699_ = Util.m_137550_();
               return true;
            }
         }
      }

      public void m_101704_() {
         if (!this.f_101695_.m_164916_()) {
            LevelSummary.BackupStatus levelsummary$backupstatus = this.f_101695_.m_164914_();
            if (levelsummary$backupstatus.m_164931_()) {
               String s = "selectWorld.backupQuestion." + levelsummary$backupstatus.m_164933_();
               String s1 = "selectWorld.backupWarning." + levelsummary$backupstatus.m_164933_();
               MutableComponent mutablecomponent = Component.m_237115_(s);
               if (levelsummary$backupstatus.m_164932_()) {
                  mutablecomponent.m_130944_(ChatFormatting.BOLD, ChatFormatting.RED);
               }

               Component component = Component.m_237110_(s1, this.f_101695_.m_78370_(), SharedConstants.m_183709_().m_132493_());
               this.f_101693_.m_91152_(new BackupConfirmScreen(this.f_101694_, (p_101736_, p_101737_) -> {
                  if (p_101736_) {
                     String s2 = this.f_101695_.m_78358_();

                     try (LevelStorageSource.LevelStorageAccess levelstoragesource$levelstorageaccess = this.f_101693_.m_91392_().m_78260_(s2)) {
                        EditWorldScreen.m_101258_(levelstoragesource$levelstorageaccess);
                     } catch (IOException ioexception) {
                        SystemToast.m_94852_(this.f_101693_, s2);
                        WorldSelectionList.f_101645_.error("Failed to backup level {}", s2, ioexception);
                     }
                  }

                  this.m_101744_();
               }, mutablecomponent, component, false));
            } else if (this.f_101695_.m_78373_()) {
               this.f_101693_.m_91152_(new ConfirmScreen((p_101741_) -> {
                  if (p_101741_) {
                     try {
                        this.m_101744_();
                     } catch (Exception exception) {
                        WorldSelectionList.f_101645_.error("Failure to open 'future world'", (Throwable)exception);
                        this.f_101693_.m_91152_(new AlertScreen(() -> {
                           this.f_101693_.m_91152_(this.f_101694_);
                        }, Component.m_237115_("selectWorld.futureworld.error.title"), Component.m_237115_("selectWorld.futureworld.error.text")));
                     }
                  } else {
                     this.f_101693_.m_91152_(this.f_101694_);
                  }

               }, Component.m_237115_("selectWorld.versionQuestion"), Component.m_237110_("selectWorld.versionWarning", this.f_101695_.m_78370_()), Component.m_237115_("selectWorld.versionJoinButton"), CommonComponents.f_130656_));
            } else {
               this.m_101744_();
            }

         }
      }

      public void m_101738_() {
         this.f_101693_.m_91152_(new ConfirmScreen((p_170322_) -> {
            if (p_170322_) {
               this.f_101693_.m_91152_(new ProgressScreen(true));
               this.m_170323_();
            }

            this.f_101693_.m_91152_(this.f_101694_);
         }, Component.m_237115_("selectWorld.deleteQuestion"), Component.m_237110_("selectWorld.deleteWarning", this.f_101695_.m_78361_()), Component.m_237115_("selectWorld.deleteButton"), CommonComponents.f_130656_));
      }

      public void m_170323_() {
         LevelStorageSource levelstoragesource = this.f_101693_.m_91392_();
         String s = this.f_101695_.m_78358_();

         try (LevelStorageSource.LevelStorageAccess levelstoragesource$levelstorageaccess = levelstoragesource.m_78260_(s)) {
            levelstoragesource$levelstorageaccess.m_78311_();
         } catch (IOException ioexception) {
            SystemToast.m_94866_(this.f_101693_, s);
            WorldSelectionList.f_101645_.error("Failed to delete world {}", s, ioexception);
         }

         WorldSelectionList.this.m_233206_();
      }

      public void m_101739_() {
         this.m_101745_();
         String s = this.f_101695_.m_78358_();

         try {
            LevelStorageSource.LevelStorageAccess levelstoragesource$levelstorageaccess = this.f_101693_.m_91392_().m_78260_(s);
            this.f_101693_.m_91152_(new EditWorldScreen((p_233244_) -> {
               try {
                  levelstoragesource$levelstorageaccess.close();
               } catch (IOException ioexception1) {
                  WorldSelectionList.f_101645_.error("Failed to unlock level {}", s, ioexception1);
               }

               if (p_233244_) {
                  WorldSelectionList.this.m_233206_();
               }

               this.f_101693_.m_91152_(this.f_101694_);
            }, levelstoragesource$levelstorageaccess));
         } catch (IOException ioexception) {
            SystemToast.m_94852_(this.f_101693_, s);
            WorldSelectionList.f_101645_.error("Failed to access level {}", s, ioexception);
            WorldSelectionList.this.m_233206_();
         }

      }

      public void m_101743_() {
         this.m_101745_();

         try (LevelStorageSource.LevelStorageAccess levelstoragesource$levelstorageaccess = this.f_101693_.m_91392_().m_78260_(this.f_101695_.m_78358_())) {
            Pair<LevelSettings, WorldCreationContext> pair = this.f_101693_.m_231466_().m_246225_(levelstoragesource$levelstorageaccess);
            LevelSettings levelsettings = pair.getFirst();
            WorldCreationContext worldcreationcontext = pair.getSecond();
            Path path = CreateWorldScreen.m_100906_(levelstoragesource$levelstorageaccess.m_78283_(LevelResource.f_78180_), this.f_101693_);
            if (worldcreationcontext.f_244272_().m_247070_()) {
               this.f_101693_.m_91152_(new ConfirmScreen((p_275882_) -> {
                  this.f_101693_.m_91152_((Screen)(p_275882_ ? CreateWorldScreen.m_275847_(this.f_101693_, this.f_101694_, levelsettings, worldcreationcontext, path) : this.f_101694_));
               }, Component.m_237115_("selectWorld.recreate.customized.title"), Component.m_237115_("selectWorld.recreate.customized.text"), CommonComponents.f_130659_, CommonComponents.f_130656_));
            } else {
               this.f_101693_.m_91152_(CreateWorldScreen.m_275847_(this.f_101693_, this.f_101694_, levelsettings, worldcreationcontext, path));
            }
         } catch (Exception exception) {
            WorldSelectionList.f_101645_.error("Unable to recreate world", (Throwable)exception);
            this.f_101693_.m_91152_(new AlertScreen(() -> {
               this.f_101693_.m_91152_(this.f_101694_);
            }, Component.m_237115_("selectWorld.recreate.error.title"), Component.m_237115_("selectWorld.recreate.error.text")));
         }

      }

      private void m_101744_() {
         this.f_101693_.m_91106_().m_120367_(SimpleSoundInstance.m_263171_(SoundEvents.f_12490_, 1.0F));
         if (this.f_101693_.m_91392_().m_78255_(this.f_101695_.m_78358_())) {
            this.m_101745_();
            this.f_101693_.m_231466_().m_233133_(this.f_101694_, this.f_101695_.m_78358_());
         }

      }

      private void m_101745_() {
         this.f_101693_.m_91346_(new GenericDirtMessageScreen(Component.m_237115_("selectWorld.data_read")));
      }

      @Nullable
      private DynamicTexture m_101746_() {
         boolean flag = this.f_101697_ != null && Files.isRegularFile(this.f_101697_);
         if (flag) {
            try {
               DynamicTexture dynamictexture1;
               try (InputStream inputstream = Files.newInputStream(this.f_101697_)) {
                  NativeImage nativeimage = NativeImage.m_85058_(inputstream);
                  Preconditions.checkState(nativeimage.m_84982_() == 64, "Must be 64 pixels wide");
                  Preconditions.checkState(nativeimage.m_85084_() == 64, "Must be 64 pixels high");
                  DynamicTexture dynamictexture = new DynamicTexture(nativeimage);
                  this.f_101693_.m_91097_().m_118495_(this.f_101696_, dynamictexture);
                  dynamictexture1 = dynamictexture;
               }

               return dynamictexture1;
            } catch (Throwable throwable1) {
               WorldSelectionList.f_101645_.error("Invalid icon for world {}", this.f_101695_.m_78358_(), throwable1);
               this.f_101697_ = null;
               return null;
            }
         } else {
            this.f_101693_.m_91097_().m_118513_(this.f_101696_);
            return null;
         }
      }

      public void close() {
         if (this.f_101698_ != null) {
            this.f_101698_.close();
         }

      }

      public String m_170324_() {
         return this.f_101695_.m_78361_();
      }

      public boolean m_214209_() {
         return !this.f_101695_.m_164916_();
      }
   }
}