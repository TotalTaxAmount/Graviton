package net.minecraft.client.telemetry;

import com.mojang.authlib.minecraft.TelemetrySession;
import com.mojang.authlib.minecraft.UserApiService;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import javax.annotation.Nullable;
import net.minecraft.SharedConstants;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ClientTelemetryManager implements AutoCloseable {
   private static final AtomicInteger f_260680_ = new AtomicInteger(1);
   private static final Executor f_260581_ = Executors.newSingleThreadExecutor((p_261485_) -> {
      Thread thread = new Thread(p_261485_);
      thread.setName("Telemetry-Sender-#" + f_260680_.getAndIncrement());
      return thread;
   });
   private final UserApiService f_260615_;
   private final TelemetryPropertyMap f_260661_;
   private final Path f_260682_;
   private final CompletableFuture<Optional<TelemetryLogManager>> f_260616_;

   public ClientTelemetryManager(Minecraft p_261610_, UserApiService p_261552_, User p_262159_) {
      this.f_260615_ = p_261552_;
      TelemetryPropertyMap.Builder telemetrypropertymap$builder = TelemetryPropertyMap.m_261098_();
      p_262159_.m_193806_().ifPresent((p_261810_) -> {
         telemetrypropertymap$builder.m_261137_(TelemetryProperty.f_260659_, p_261810_);
      });
      p_262159_.m_193805_().ifPresent((p_261690_) -> {
         telemetrypropertymap$builder.m_261137_(TelemetryProperty.f_260475_, p_261690_);
      });
      telemetrypropertymap$builder.m_261137_(TelemetryProperty.f_260530_, UUID.randomUUID());
      telemetrypropertymap$builder.m_261137_(TelemetryProperty.f_260597_, SharedConstants.m_183709_().m_132492_());
      telemetrypropertymap$builder.m_261137_(TelemetryProperty.f_260441_, Util.m_137581_().m_183999_());
      telemetrypropertymap$builder.m_261137_(TelemetryProperty.f_260586_, System.getProperty("os.name"));
      telemetrypropertymap$builder.m_261137_(TelemetryProperty.f_260562_, Minecraft.m_193589_().m_184597_());
      this.f_260661_ = telemetrypropertymap$builder.m_260981_();
      this.f_260682_ = p_261610_.f_91069_.toPath().resolve("logs/telemetry");
      this.f_260616_ = TelemetryLogManager.m_261252_(this.f_260682_);
   }

   public WorldSessionTelemetryManager m_260825_(boolean p_262073_, @Nullable Duration p_261589_) {
      return new WorldSessionTelemetryManager(this.m_261052_(), p_262073_, p_261589_);
   }

   private TelemetryEventSender m_261052_() {
      if (SharedConstants.f_136183_) {
         return TelemetryEventSender.f_260501_;
      } else {
         TelemetrySession telemetrysession = this.f_260615_.newTelemetrySession(f_260581_);
         if (!telemetrysession.isEnabled()) {
            return TelemetryEventSender.f_260501_;
         } else {
            CompletableFuture<Optional<TelemetryEventLogger>> completablefuture = this.f_260616_.thenCompose((p_261737_) -> {
               return p_261737_.map(TelemetryLogManager::m_260856_).orElseGet(() -> {
                  return CompletableFuture.completedFuture(Optional.empty());
               });
            });
            return (p_261827_, p_261818_) -> {
               if (!p_261827_.m_260839_() || Minecraft.m_91087_().m_260979_()) {
                  TelemetryPropertyMap.Builder telemetrypropertymap$builder = TelemetryPropertyMap.m_261098_();
                  telemetrypropertymap$builder.m_260832_(this.f_260661_);
                  telemetrypropertymap$builder.m_261137_(TelemetryProperty.f_260726_, Instant.now());
                  telemetrypropertymap$builder.m_261137_(TelemetryProperty.f_260453_, p_261827_.m_260839_());
                  p_261818_.accept(telemetrypropertymap$builder);
                  TelemetryEventInstance telemetryeventinstance = new TelemetryEventInstance(p_261827_, telemetrypropertymap$builder.m_260981_());
                  completablefuture.thenAccept((p_262038_) -> {
                     if (!p_262038_.isEmpty()) {
                        p_262038_.get().m_260877_(telemetryeventinstance);
                        telemetryeventinstance.m_261105_(telemetrysession).send();
                     }
                  });
               }
            };
         }
      }
   }

   public Path m_260914_() {
      return this.f_260682_;
   }

   public void close() {
      this.f_260616_.thenAccept((p_261643_) -> {
         p_261643_.ifPresent(TelemetryLogManager::close);
      });
   }
}